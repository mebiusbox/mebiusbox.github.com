<?php
/**
 * @file
 * @brief ����������ܴ���
 * @author typezero
 */
?>
<?php
require_once("common.php");


// ���������������¥����å�
if (empty($_SESSION['admin'])) {
    goto_error_page(lang_get('error', 'illegal_access_level'));
}


//------------------------------------------------------------


print(Bugboard_HeaderTemplate(
    Bugboard_custom_field_form_check_js()));
print(Bugboard_AdminTemplate(make_admin_commands()));


//------------------------------------------------------------

$db = &$db_;

$num = $db->getOne("SELECT COUNT(*) FROM ".BUGBOARD_CUSTOM_FIELD_TABLE);
$rs = $db->query("SELECT * FROM ".BUGBOARD_CUSTOM_FIELD_TABLE." ORDER BY seq");

//------------------------------------------------------------

$html = new Html_Writer($buf);
$html->writeln('<div class="sub_contents">');
$html->writeln('<div class="sub_title">����������ܤο�������</div>');
$html->writeln('<div class="component">');
$html->writeln(make_tag("form",
                  array("action"=>"manage_custom_field_edit_action.php",
                        "method"=>"post",
                        "name"=>"new_custom_field_form",
                        "onSubmit"=>"return new_custom_field_form_check()")));
$html->writeln('<input type="hidden" name="acttype" value="new">');
$html->writeln('<input type="text" name="name" size="40" maxlength="255">');
$html->writeln("&nbsp;".'<input type="submit" value="��������">');
$html->writeln('</form>');
$html->writeln('</div></div>');

//------------------------------------------------------------

$html->writeln('<div class="sub_contents">');
$html->writeln('<div class="sub_title">����������ܰ���</div>');

$html->writeln('<form action="manage_custom_field_edit_action.php" method="post">');
$html->writeln('<input type="hidden" name="acttype" value="sort">');

$tbl = new Gull_Table_Html(array("class"=>"selectbox"));
$tbl->beginRow();
$tbl->insertHeadCenter("����̾");
$tbl->insertHeadCenter("��");
$tbl->insertHeadCenter("��ꤦ����");
$tbl->insertHeadCenter("�ǥե������");
$tbl->insertHeadCenter("����");
$tbl->endRow();
$tbl->setInterlaceMode(true);

$options = "";
for ($i=1; $i<=$num; $i++) {
    $options .= "<option>".$i."</option>";
}

$i = 1;
while ($row = $rs->fetchRow(DB_FETCHMODE_ASSOC)) {
    $tbl->beginRow();
    $tbl->insertData("<a href=\"manage_custom_field_edit.php?fid=".$row['id']."\">".$row['name']."</a>");
    $tbl->insertData(lang_get('custom_field_type',$row['type']));
    $tbl->insertData($row['possible_values']);
    $tbl->insertData($row['default_value']);

    $options_tmp = $options;
    $options_tmp = str_replace("<option>".$i."</option>", "<option selected>".$i."</option>", $options_tmp);
    $tbl->insertData(make_tag_closed("select",
                                     array("name"=>"seq_".$row['id']),
                                     $options_tmp));
    $tbl->endRow();
    $i++;
}
$tbl->insertDataBlank(array("colspan"=>4));
$tbl->insertData(make_input_tag("submit", "", "�¤��ؤ�"));
$tbl->endTable();

print($tbl->to_html());
$html->writeln('</form>');
$html->writeln('</div>');

//------------------------------------------------------------

print(Bugboard_FooterTemplate());
?>
