<?php
/**
 * @file
 * @brief Logout
 * @author typezero
 */
?>
<?php

session_start();

require_once("./core/const_inc.php");
require_once("./config.php");
require_once("./alias-db.php");
require_once("./templates/common.php");
require_once("Auth/Auth.php");

//------------------------------------------------------------

function goto_error_page($err, $comment=null) {

    print(Bugboard_HeaderTemplate());
    print(Bugboard_ErrorboxTemplate($err,$comment));
    print(Bugboard_FooterTemplate());
    exit(0);
}

function goto_info_page($caption="", $summary="", $comment=null) {

    print(Bugboard_HeaderTemplate());
    print(Bugboard_InfoboxTemplate($caption,$summary,$comment));
    print(Bugboard_FooterTemplate());
    exit(0);
}

//------------------------------------------------------------

/**
 * @brief ǧ�ڤ����������Ȥ��˸ƤФ��ؿ�
 */
function bugboard_auth_login_callback($username, $auth) {

    session_regenerate_id();//���å�������ɻ�

    $_SESSION['username'] = $username;
    $_SESSION['step'] = BUGBOARD_STEP_READY;
    $_SESSION['viewmode'] = 'normal';
    $_SESSION['admin']    = TRUE;
    $_SESSION['nickname'] = $auth->getAuthData('nickname');
}

/**
 */
function loginFunction($usr, $status) {
    
    switch ($status) {
    case AUTH_IDLED:
    case AUTH_EXPIRED:
        $err = "����������¤��ڤ�Ƥ��ޤ����ƥ������󤷤Ƥ���������";
        break;
    case AUTH_WRONG_LOGIN:
        $err = "�桼���ɣĤ⤷���ϥѥ���ɤ��ְ�äƤ��ޤ���";
        break;
    }

    print(Bugboard_HeaderTemplate());
    print(Bugboard_LoginTemplate($err));
    print(Bugboard_FooterTemplate());
}

/**
 * @brief ǧ��
 */
function bugboard_auth() {

    $params = array(
        "dsn" => BUGBOARD_DB_SQLTYPE."://".BUGBOARD_DB_USERNAME.":".BUGBOARD_DB_PASS."@".BUGBOARD_DB_HOST."/".BUGBOARD_DB_NAME,
        "table" => BUGBOARD_USER_TABLE,
        "usernamecol" => "name",
        "passwordcol" => "pass",
        "cryptType" => "MD5",//�Ź沽�ʥǥե���Ȥ�MD5��
        "db_fields" => "*",//����¾�Υե�����ɤ����
        );

    $a = new Auth("DB", $params, "LoginFunction");
    $a->setLoginCallback(bugboard_auth_login_callback);
    $a->start();

    if ($a->getAuth()) {
    }
    else {
        return NULL;
    }

    if ($_SESSION['step'] == BUGBOARD_STEP_ERROR) {//
        if (isset($a) && $a->checkAuth()) {
            $a->logout();
        }
        return NULL;
    }

    return $a;
}

//------------------------------------------------------------

if (empty($_SESSION)) {
    goto_error_page("������������");
}

$a = bugboard_auth();
if (empty($a)) {
    exit(1);
}

Header("Location: index.php");

?>