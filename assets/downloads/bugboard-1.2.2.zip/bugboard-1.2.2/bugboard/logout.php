<?php
/**
 * @file
 * @brief Logout
 * @author typezero
 */
?>
<?php

session_start();
session_destroy();

Header("Location: index.php");

?>
