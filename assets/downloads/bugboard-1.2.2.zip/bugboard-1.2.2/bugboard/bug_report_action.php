<?php
/**
 * @file
 + @brief ��ݡ����Խ��ν���
 * @author typezero
 */
?>
<?php
require_once("common.php");
require_once("gen_rss.php");

// �����������������å�
if (empty($_GET['bid'])) {
    goto_error_page(lang_get('error', 'illegal_access'));
}

// ��ݡ���¸�ߥ����å�
if (is_report_exists($db_, $_GET['bid']) == false) {
    goto_error_page(lang_get('error', 'report_not_found'));
}

// �����������������å�2
if (empty($_POST['acttype'])) {
    if (!empty($_GET['acttype'])) {
        $acttype = $_GET['acttype'];
    }
    else {
        goto_error_page(lang_get('error', 'illegal_access'));
    }
}
else {
    $acttype = $_POST['acttype'];
}


//------------------------------------------------------------


$bid = $_GET['bid'];
$loc = "view_report.php?bid=".$bid;
$step = "";
$err = "";

$db = &$db_;

//------------------------------------------------------------

mb_convert_variables(BUGBOARD_INTERNAL_ENCODING, BUGBOARD_HTML_ENCODING, $_POST);

function filter_string($val) {
    return stripslashes(bugboard_mb_trim($val));
}

$in_param = array();
foreach ($_POST as $key=>$value) {
    $in_param[$key] = filter_string($value);
}

//------------------------------------------------------------

/**
 * @brief
 */
if ($acttype == 'update') {

    // check input value
    if ($in_param['summary'] == "") {
        $err .= lang_get('error', 'form_summary_empty')."<br>";
    }
    if ($in_param['body'] == "") {
        $err .= lang_get('error', 'form_body_empty')."<br>";
    }
    if ($err != "") {
        $o_smarty->goto_error_page(lang_get('error', 'form_omission'), $err);
    }
    
    $bug = $db->getRow("SELECT * FROM ".BUGBOARD_BUG_TABLE." WHERE id=?", array($bid), DB_FETCHMODE_ASSOC);
    $body = $db->getOne("SELECT body FROM ".BUGBOARD_BUG_TEXT_TABLE." WHERE id=?", array($bug['body_id']));

    $items = array();
    $field_name = array('category', 'severity', 'summary');
    foreach ($field_name as $wk) {
        if ($bug[$wk] != $in_param[$wk]) {
            array_push($items, array(BUGBOARD_BUG_HISTORY_ACTION_MODIFY, BUGBOARD_BUG_HISTORY_TARGET_DEFAULT, "bug_".$wk, $bug[$wk], $in_param[$wk]));
        }
    }

    $now = date("Y/m/d H:i:s");
    
    $db->autoCommit();

    // custom field
    $cf_array = array();
    foreach ($in_param as $key=>$value) {
        if (mb_ereg("(__custom_field_)([0-9]+)", $key, $m)) {
            if (empty($cf_array[ $m[2] ])) {
                $cf_array[ $m[2] ] = $value;
            }
            else {
                $cf_array[ $m[2] ] .= '|'.$value;
            }
        }
    }

    $rs = $db->query("SELECT id FROM ".BUGBOARD_CUSTOM_FIELD_TABLE);
    while ($row = $rs->fetchRow()) {
        
        $cf_body = $db->getOne("SELECT value FROM ".BUGBOARD_CUSTOM_FIELD_STRING_TABLE." WHERE fid=? AND bid=?", array($row['id'],$bid));

        if ($cf_body != $cf_array[$fid]) {
            array_push($items, array(BUGBOARD_BUG_HISTORY_ACTION_MODIFY, BUGBOARD_BUG_HISTORY_TARGET_CUSTOM_FIELD, $cf['name'], $cf_body, $cf_array[$fid]));
            $ret = $db->query("UPDATE ".BUGBOARD_CUSTOM_FIELD_STRING_TABLE." SET value=? WHERE fid=? AND bid=?",
                              array($cf_array[$fid], $fid, $bug['id']));
        }
    }

    if ($in_param['body'] != $body) {
        array_push($items, array(BUGBOARD_BUG_HISTORY_ACTION_MODIFY, BUGBOARD_BUG_HISTORY_TARGET_DEFAULT, 'bug_body', "", ""));
        $ret = $db->query("UPDATE ".BUGBOARD_BUG_TEXT_TABLE." SET body=? WHERE id=?", array($in_param['body'], $bug['body_id']));
    }

    if (count($items)>0) {
        $fields = array('category'=>$in_param['category'],
                        'severity'=>$in_param['severity'],
                        'summary'=>$in_param['summary'],
                        'last_updated'=>$now,
                        'last_updater'=>$_SESSION['nickname']);
        $ret = $db->autoExecute(BUGBOARD_BUG_TABLE, $fields, DB_AUTOQUERY_UPDATE, "id=".$bid);
    }

    $db->commit();

    if (BUGBOARD_MAIL_NOTIFICATION && in_array('update_report', $bugboard_mail_notification_event_list)) {

        $summary = $in_param['summary'];
        $summary = mb_convert_kana($summary);
        $summary = htmlspecialchars($summary);

        $name    = mb_convert_kana($_SESSION['nickname']);
        $name    = htmlspecialchars($name);

        $detail  = "";
        if ($in_param['summary'] != $bug['summary']) {
            $detail .= '���פ��ѹ�����ޤ���\r\n';
        }
        if ($in_param['body'] != $body) {
            $detail .= '��ʸ���ѹ�����ޤ���\r\n';
        }
        if ($in_param['category'] != $bug['category']) {
            $detail .= '���ƥ��꤬�ѹ�����ޤ���\r\n';
        }
        if ($in_param['severity'] != $bug['severity']) {
            $detail .= '�����٤��ѹ�����ޤ���\r\n';
        }
        if ($detail === "") {
            $detail .= '����������ܤ��ѹ�����ޤ���\r\n';
        }

        bugboard_send_mail(
            array(
                'email_list' => $bugboard_mail_notification_email_list,
                'from' => BUGBOARD_MAIL_NOTIFICATION_SENDER,
                'subject' => $summary.' by '.$name.' [update]',
                'body' => $detail,
                'cc_list' => $bugboard_mail_notification_cc_list,
                'bcc_list' => $bugboard_mail_notification_bcc_list));
    }
    
    log_debug("��ݡ��� > ��������� > ���� > ����");
}
elseif ($acttype == 'delete') {
    /*
     * -------------------------------------------------------------
     * delete
     * -------------------------------------------------------------
     */

    $db->autoCommit();
    remove_report($db, $bid);
    $db->commit();

    $html = '<input type="button" value="���Ĥ��롡" onclick="window.close();">';
    goto_info_page("���", "��ݡ��Ȥ������ޤ���<br><br>".$html);
    exit(0);
}
elseif ($acttype == 'resolve') {
    /*
     * -------------------------------------------------------------
     * resolve
     * -------------------------------------------------------------
     */
    $status     = null;
    if (isset($in_param['fixed'])) {
        $status     = BUGBOARD_BUG_STATUS_FIXED;
    }
    else if (isset($in_param['suspend'])) {
        $status     = BUGBOARD_BUG_STATUS_SUSPEND;
    }
    else if (isset($in_param['start'])) {
        $status     = BUGBOARD_BUG_STATUS_START;
    }
    else if (isset($in_param['notrepro'])) {
        $status     = BUGBOARD_BUG_STATUS_NOTREPRO;
    }
    else if (isset($in_param['checked'])) {
        $status     = BUGBOARD_BUG_STATUS_CHECKED;
    }
    else if (isset($in_param['feedback'])) {
        $status     = BUGBOARD_BUG_STATUS_FEEDBACK;
    }
    else if (isset($in_param['rejected'])) {
        $status     = BUGBOARD_BUG_STATUS_REJECTED;
    }
    else if (isset($in_param['closed'])) {
        $status     = BUGBOARD_BUG_STATUS_CLOSED;
    }
    else {
        goto_error_page(lang_get('error', 'illegal_param'));
    }

    $status_old = $db->getOne("SELECT status FROM ".BUGBOARD_BUG_TABLE." WHERE id=?", array($bid));
    if ($status_old != $status) {
    
        $db->autoCommit();

        $now     = date("Y/m/d H:i:s");
        $ret = $db->query("UPDATE ".BUGBOARD_BUG_TABLE." SET status=?,last_updated=?,last_updater=? WHERE id=?",
                              array($status, $now, $_SESSION['nickname'], $bid));
        $db->commit();

        if (BUGBOARD_MAIL_NOTIFICATION && in_array('change_status', $bugboard_mail_notification_event_list)) {

            $summary = $db->getOne('SELECT summary FROM '.BUGBOARD_BUG_TABLE." WHERE id=?", array($bid));
            $summary = mb_convert_kana($summary);
            $summary = htmlspecialchars($summary);

            $name    = mb_convert_kana($_SESSION['nickname']);
            $name    = htmlspecialchars($name);

            $detail  = "[".lang_get('bug_status', $status_old)."]";
            $detail .= " -> ";
            $detail .= "[".lang_get('bug_status', $status)."]";

            bugboard_send_mail(
                array(
                    'email_list' => $bugboard_mail_notification_email_list,
                    'from' => BUGBOARD_MAIL_NOTIFICATION_SENDER,
                    'subject' => $summary.' by '.$name.' [change_status]',
                    'body' => $detail,
                    'cc_list' => $bugboard_mail_notification_cc_list,
                    'bcc_list' => $bugboard_mail_notification_bcc_list));
        }

        log_debug("��ݡ��� > ������� > ����");
    }
}
elseif ($acttype == 'add_file') {
    /*
     * -------------------------------------------------------------
     * add_file
     * -------------------------------------------------------------
     */
    if (isset($_FILES['attach_file']['name'])) {

        log_debug($_FILES['attach_file']['error']);

        $filename = mb_convert_encoding($_FILES['attach_file']['name'],
                                        BUGBOARD_INTERNAL_ENCODING,
                                        BUGBOARD_HTML_ENCODING);

        $upload_dir = "./attach/";
        $diskfile = bugboard_upload_file($upload_dir, $_FILES['attach_file']);
        if (is_null($diskfile)) {
            goto_error_page(lang_get('error', 'upload_failed'));
        }

        $now = date("Y/m/d H:i:s");
        
        $db->autoCommit();
        $attach_id = $db->nextId(BUGBOARD_BUG_FILE_ID_SEQ);
        $fields = "id,bid,diskfile,filename,folder,filesize,file_type,date_added";
        $ret = $db->query("INSERT INTO ".BUGBOARD_BUG_FILE_TABLE."(".$fileds.") VALUES(?,?,?,?, ?,?,?,?)",
                          array($attach_id, $bid,
                                $diskfile,
                                $filename,
                                $upload_dir,
                                $_FILES['attach_file']['size'],
                                $_FILES['attach_file']['type'],
                                $now));

        $db->commit();
        log_debug("==================== attach file");
        log_debug($_FILES['attach_file']);
    }
}
elseif ($acttype == 'remove_file') {
    /*
     * -------------------------------------------------------------
     * remove_file
     * -------------------------------------------------------------
     */
    if (empty($_GET['fid'])) {
        goto_error_page(lang_get('error', 'illegal_access'));
    }
    if (is_attach_file_exists($db, $_GET['fid']) == false) {
        goto_error_page(lang_get('error', 'attach_file_not_found'));
    }

    $filename = $db->getOne("SELECT filename FROM ".BUGBOARD_BUG_FILE_TABLE." WHERE id=?",
                            array($_GET['fid']));
    
    $db->autoCommit();
    $sql_gen = new Sql_Gen("DELETE", BUGBOARD_BUG_FILE_TABLE);
    $sql_gen->set_where("id=?");
    $ret = $db->query($sql_gen->gen(), array($_GET['fid']));
    $now = date("Y/m/d H:i:s");
    $db->commit();
}
elseif ($acttype == 'comment_add') {
    /*
     * -------------------------------------------------------------
     * comment_add
     * -------------------------------------------------------------
     */
    $comment = $in_param['comment'];
    if ($comment == "") {
        
        unset($_SESSION['tmp']);
        $_SESSION['tmp']['name'] = $in_param['name'];
        $_SESSION['tmp']['body'] = $comment;
        
        goto_error_page(lang_get('error', 'form_omission'),
                                   lang_get('error', 'form_comment_empty'));
    }

    if (bugboard_captcha_is_enable() && isset($_SESSION['code'])) {
        // ��ƥ��������å�
        if ($_SESSION['code'] != $in_param['regkey']) {

            unset($_SESSION['tmp']);
            $_SESSION['tmp']['name'] = $in_param['name'];
            $_SESSION['tmp']['body'] = $comment;
            
            goto_error_page(lang_get('error', 'form_error'),
                            lang_get('error', 'form_illegal_regkey'));
        }
    }

    if (BUGBOARD_ANTISPAM_A_TAG)
    {
        // a ���������ä�������̵�Ѥǥ��ѥష��

        mb_regex_encoding(BUGBOARD_INTERNAL_ENCODING);
        if (mb_ereg("[hH][rR][eE][fF]", $comment)) {
            unset($_SESSION['tmp']);
            $_SESSION['tmp']['name'] = $in_param['name'];
            $_SESSION['tmp']['body'] = $comment;

            goto_error_page(lang_get('error', 'form_error'),
                            lang_get('error', 'form_illegal_value'));
        }
    }
    
    $db->autoCommit();
    $note_id      = $db->nextId(BUGBOARD_BUG_NOTE_ID_SEQ);
    $note_text_id = $db->nextId(BUGBOARD_BUG_NOTE_TEXT_ID_SEQ);

    $ret = $db->query("INSERT INTO ".BUGBOARD_BUG_NOTE_TEXT_TABLE."(id,body) VALUES(?,?)",
                      array($note_text_id, $comment));

    $now = date("Y/m/d H:i:s");
    $ret = $db->query("INSERT INTO ".BUGBOARD_BUG_NOTE_TABLE."(id,bid,name,body_id,date_submitted) VALUES(?,?,?,?,?)",
                      array($note_id, $bid, $in_param['name'], $note_text_id, $now));

    $ret = $db->query("UPDATE ".BUGBOARD_BUG_TABLE." SET last_updated=?,last_updater=? WHERE id=?",
                      array($now, $in_param['name'], $bid));

    $db->commit();

    gen_comments_rss($db);
    unset($_SESSION['tmp']);

    if (BUGBOARD_MAIL_NOTIFICATION && in_array('add_comment', $bugboard_mail_notification_event_list)) {

        $summary = $db->getOne('SELECT summary FROM '.BUGBOARD_BUG_TABLE." WHERE id=?", array($bid));
        $summary = mb_convert_encoding($summary, BUGBOARD_INTERNAL_ENCODING, BUGBOARD_DB_ENCODING);
        $summary = mb_convert_kana($summary);
        $summary = htmlspecialchars($summary);

        $comment = mb_convert_kana($comment);
        $comment = htmlspecialchars($comment);

        $name    = mb_convert_kana($in_param['name']);
        $name    = htmlspecialchars($name);

        bugboard_send_mail(
            array(
                'email_list' => $bugboard_mail_notification_email_list,
                'from' => BUGBOARD_MAIL_NOTIFICATION_SENDER,
                'subject' => $summary.' by '.$name.' [comment]',
                'body' => $comment,
                'cc_list' => $bugboard_mail_notification_cc_list,
                'bcc_list' => $bugboard_mail_notification_bcc_list));
    }

    log_debug("��ݡ��� > �������ɲ� > ����");
}
elseif ($acttype == 'remove_comment') {
    /*
     * -------------------------------------------------------------
     * remove_comment
     * -------------------------------------------------------------
     */
    if (empty($_GET['cid'])) {
        goto_error_page(lang_get('error', 'illegal_access'));
    }
    if (is_comment_exists($db, $_GET['cid']) == false) {
        goto_error_page(lang_get('error', 'comment_not_found'));
    }

//[#0000036]
//    $sub_sql = new Sql_Gen_Select(BUGBOARD_BUG_NOTE_TABLE, array("body_id"), "id=?");
//    $sql_gen = new Sql_Gen_Select(BUGBOARD_BUG_NOTE_TEXT_TABLE, array("body"));
//    $sql_gen->set_where("id = (".$sub_sql->gen().")");
//    $comment = $db->getOne($sql_gen->gen(), array($_GET['cid']));

    $db->autoCommit();
    $sql_gen = new Sql_Gen("DELETE", BUGBOARD_BUG_NOTE_TABLE);
    $sql_gen->set_where("id=?");
    $ret = $db->query($sql_gen->gen(), array($_GET['cid']));

    $db->commit();
    log_debug("��ݡ��� > �����Ⱥ�� > ����");
}
elseif ($acttype == 'vote') {
    /*
     * -------------------------------------------------------------
     * vote
     * -------------------------------------------------------------
     */
    $count = $db->getOne("SELECT vote_count FROM ".BUGBOARD_BUG_TABLE." WHERE id=?", array($bid));
    $db->query("UPDATE ".BUGBOARD_BUG_TABLE." SET vote_count=? WHERE id=?", array($count+1, $bid));
}

Header("Location:".$loc);

?>
