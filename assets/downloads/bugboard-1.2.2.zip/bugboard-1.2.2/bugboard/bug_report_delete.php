<?php
/**
 * @file
 * @brief ��ݡ��Ȥκ����ǧ
 * @author typezero
 */
?>
<?php
require_once("common.php");


// �����������������å�
if (empty($_GET['bid'])) {
    goto_error_page(lang_get('error', 'illegal_access'));
}

// ��ݡ��Ȥ�¸�ߥ����å�
if (is_report_exists($db_, $_GET['bid']) == false) {
    goto_error_page(lang_get('error', 'report_not_found'));
}

// ���������������¥����å�
if (empty($_SESSION['admin'])) {
    goto_error_page(lang_get('error', 'illegal_access_level'));
}


//------------------------------------------------------------


$bid = $_GET['bid'];
$db  = &$db_;


print(Bugboard_HeaderTemplate());


//assign("sub_title", "��ݡ��Ⱥ����ǧ");
//assign("sidebar", sidebar_to_html(get_db(), array("mode"=>"manage_project")));

$html = new Html_BufferedWriter($buf);

$html->writeln('<div class="sub_contents">');
$html->writeln('<div class="sub_title">��ݡ��Ⱦ���</div>');

$sql_gen = new Sql_Gen_Select(BUGBOARD_BUG_TABLE.", ".BUGBOARD_BUG_TEXT_TABLE);
$sql_gen->set_field(array(BUGBOARD_BUG_TABLE.".*", BUGBOARD_BUG_TEXT_TABLE.".body"));
$sql_gen->set_where(BUGBOARD_BUG_TABLE.".id=? AND ".BUGBOARD_BUG_TABLE.".body_id=".BUGBOARD_BUG_TEXT_TABLE.".id");
$report = $db->getRow($sql_gen->gen(), array($bid), DB_FETCHMODE_ASSOC);

$tbl = new Gull_Table_Html(array("class"=>"listbox"));
$tbl->setInterlaceMode(true);

$tbl->beginRow();
$tbl->insertHead("ID", array("style"=>"width:20%"));
$tbl->insertData(id_to_str($report['id']));
$tbl->endRow();

$tbl->beginRow();
$tbl->insertHead(lang_get('bug_summary_name'), array("style"=>"width:20%"));
$tbl->insertData(htmlspecialchars($report['summary']));
$tbl->endRow();

$tbl->beginRow();
$tbl->insertHead(lang_get('bug_body_name'), array("style"=>"width:20%"));
$tbl->insertData(htmlspecialchars($report['body']));
$tbl->endRow();
$tbl->endTable();

$html->writeln($tbl->to_html());
$html->writeln("</div>");


$html->writeln('<div class="sub_contents"><div style="text-align:center;margin:4px">');
$html->writeln('<span style="color:red">�����˺�����Ƥ��������Ǥ�����</span>&nbsp;');
$html->writeln('<form action="bug_report_action.php?bid='.$bid.'" method="post">');
$html->writeln('<input type="hidden" name="acttype" value="delete">');
$html->writeln('<input type="submit" value="���Ϥ���">');
$html->writeln('</form></div></div>');

print($html->get());
print(Bugboard_FooterTemplate());

?>
