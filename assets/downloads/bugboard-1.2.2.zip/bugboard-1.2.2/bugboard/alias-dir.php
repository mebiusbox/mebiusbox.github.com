<?php
/**
 * @file
 * @brief �����������ӣ��У�
 * @author typezero
 */
?>
<?php

// base dir
$g_base_dir = dirname(__FILE__).DIRECTORY_SEPARATOR;

// core dir
$g_core_dir = $g_base_dir.'core'.DIRECTORY_SEPARATOR;

// javascript
$g_javascript_dir = $g_base_dir.'javascript'.DIRECTORY_SEPARATOR;

// css
$g_css_dir = $g_base_dir.'css'.DIRECTORY_SEPARATOR;

// lang
$g_lang_dir = $g_base_dir.'lang'.DIRECTORY_SEPARATOR;

// attach
$g_attach_file_dir = $g_base_dir.'attach'.DIRECTORY_SEPARATOR;

// log
$g_log_dir = $g_base_dir.'log'.DIRECTORY_SEPARATOR;

// img
$g_img_dir = $g_base_dir.'img'.DIRECTORY_SEPARATOR;

?>
