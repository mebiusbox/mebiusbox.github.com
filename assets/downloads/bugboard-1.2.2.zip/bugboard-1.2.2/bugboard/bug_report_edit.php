<?php
/**
 * @file
 * @brief ��ݡ����Խ�
 * @author typezero
 */
?>
<?php
require_once("common.php");
require_once("./templates/view.php");
require_once("./templates/view_report.php");

// �����������������å�
if (empty($_GET['bid'])) {
    goto_error_page(lang_get('error', 'illegal_access'));
}
// ��ݡ���¸�ߥ����å�
if (is_report_exists($db_, $_GET['bid']) == false) {
    goto_error_page(lang_get('error', 'report_not_found'));
}
// �����������������å�
if (empty($_SESSION['admin'])) {
    goto_error_page(lang_get('error', 'illegal_access'));
}


//------------------------------------------------------------

print(Bugboard_HeaderTemplate(Bugboard_report_form_check_js()));
print(Bugboard_AdminTemplate(make_admin_commands()));


$bid = $_GET['bid'];
$db = &$db_;

// ��ݡ��Ⱦ������
$sql_gen = new Sql_Gen_Select(BUGBOARD_BUG_TABLE.", ".BUGBOARD_BUG_TEXT_TABLE);
$sql_gen->set_field(array(BUGBOARD_BUG_TABLE.".*", BUGBOARD_BUG_TEXT_TABLE.".body"));
$sql_gen->set_where(BUGBOARD_BUG_TABLE.".id=? AND ".BUGBOARD_BUG_TABLE.".body_id=".BUGBOARD_BUG_TEXT_TABLE.".id");
$report = $db->getRow($sql_gen->gen(), array($bid), DB_FETCHMODE_ASSOC);

// custom field
$custom_fields = array();
$rs = $db->query("SELECT * FROM ".BUGBOARD_CUSTOM_FIELD_TABLE." ORDER BY seq");
while ($row = $rs->fetchRow(DB_FETCHMODE_ASSOC)) {
    $custom_field = null;
    $custom_field['id']    = $row['id'];
    $custom_field['name']  = $row['name'];
    $custom_field['type']  = $row['type'];
    $custom_field['value'] = htmlspecialchars($db->getOne("SELECT value FROM ".BUGBOARD_CUSTOM_FIELD_STRING_TABLE." WHERE fid=? AND bid=?", array($row['id'],$bid)));
    array_push($custom_fields, $custom_field);
}

// category
$tmp = $db->getCol("SELECT category FROM ".BUGBOARD_CATEGORY_TABLE, 0);
$categories = null;
foreach($tmp as $value) {
    $categories[$value] = htmlspecialchars($value);
}
if (in_array($report['category'], $tmp) == false) {
    $categories[ $report['category'] ] = $report['category'];
}

$html  = '<div class="sub_contents">';
$html .= '<div class="sub_title">��ݡ����Խ�</div>';

$html .= make_tag("form",
                  array("action"=>"bug_report_action.php?bid=".$bid,
                        "method"=>"post",
                        "name"=>"report_form",
                        "onSubmit"=>"return report_form_check()"));
$html .= make_tag("input",
                  array("type"=>"hidden", "name"=>"acttype", "value"=>"update"));

$tbl = new Gull_Table_Html(array("class"=>"listbox"));

$tbl->beginRow();
$tbl->insertHeadCenter("ID", array("style"=>"width:20%"));
$tbl->insertHeadCenter("���ƥ���", array("style"=>"width:20%"));
$tbl->insertHeadCenter("������", array("style"=>"width:20%"));
$tbl->insertHeadCenter("���ơ�����");
$tbl->insertHeadBlank();
$tbl->endRow();

$tbl->beginRow();
$tbl->insertDataCenter(id_to_str($report['id']));
$tbl->insertDataCenter(make_select_tag($categories, $report['category'], array("name"=>"category")));
$tbl->insertDataCenter(make_select_tag(lang_get('bug_severity'), $report['severity'], array("name"=>"severity")));
$tbl->insertDataCenter(lang_get('bug_status', $report['status']), array("class"=>getBugStatusClass($report['status'])));
$tbl->insertDataBlank();
$tbl->endRow();
$tbl->nextTile();

$tbl->beginRow();
$tbl->insertHeadCenter("����");
$tbl->insertHeadCenter("�����");
$tbl->insertHeadCenter("�ǽ�������");
$tbl->insertHeadCenter("�ǽ�������");
$tbl->insertHeadCenter("��ɼ��");
$tbl->endRow();

$tbl->beginRow();
$tbl->insertDataCenter(htmlspecialchars($report['reporter']));
$tbl->insertDataCenter(date_as_text($report['date_submitted']), array("nowrap"));
$tbl->insertDataCenter(htmlspecialchars($report['last_updater']));
$tbl->insertDataCenter(date_as_text($report['last_updated']));
$tbl->insertDataCenter($report['vote_count']);
$tbl->endRow();
$tbl->nextTile();

$tbl->insertBlankRow();

$tbl->beginRow();
$tbl->insertHead(lang_get('bug_summary_name'));
$tbl->insertData(make_tag("input", array("type"=>"text", "size"=>100, "maxlength"=>128,
                                         "name"=>"summary",
                                         "value"=>$report['summary'])),
                 array("colspan"=>"4"));
$tbl->endRow();
$tbl->nextTile();

$tbl->beginRow();
$tbl->insertHead(lang_get('bug_body_name'));
$tbl->insertData(make_tag_closed("textarea",
                                 array("name"=>"body",
                                       "cols"=>80,
                                       "rows"=>8),
                                 $report['body']),
                 array("colspan"=>"4"));
$tbl->endRow();
$tbl->nextTile();

// custom fields

if (count($custom_fields)>0) {
    
    $tbl->insertBlankRow();
    
    foreach ($custom_fields as $param) {
        
        $tbl->beginRow();
        $tbl->insertHead(htmlspecialchars($param['name']));

        switch ($param['type']) {
        case BUGBOARD_CUSTOM_FIELD_TYPE_STRING:
            $tbl->insertData(make_tag("input", array("type"=>"text",
                                                     "size"=>100,
                                                     "name"=>"__custom_field_".$param['id'],
                                                     "value"=> htmlspecialchars($param['value']))),
                             array("colspan"=>4));
            break;

        case BUGBOARD_CUSTOM_FIELD_TYPE_LIST:
            $values = explode("|", $param['possible_values']);
            $tmp = null;
            foreach($values as $value) {
                $tmp[$value] = htmlspecialchars($value);
            }
            $tbl->insertData(make_select_tag($tmp, htmlspecialchars($param['value']), array("name"=>"__custom_field_".$param['id'])),
                             array("colspan"=>4));
            break;

        case BUGBOARD_CUSTOM_FIELD_TYPE_CHECKBOX:

            $possible_values = explode("|", $param['possible_values']);
            $checked_values  = explode("|", $param['value']);

            $buf = new Html_Buffer;
            $tmp = new Html_Writer($buf);
            $cnt = 0;

            $sp  = "&nbsp;";
            $sp2 = str_repeat($sp,2);
            
            foreach ($possible_values as $item) {
                if ($item == "") {
                    $tmp->writebr();
                }
                else {
                    $opt = array("type"=>"checkbox",
                                 "name"=>"__custom_field_".$param['id']."_".$cnt,
                                 "value"=> htmlspecialchars($item));
                    if (in_array($item, $checked_values)) {
                        array_push($opt, "checked");
                    }
                    $tmp->write(make_tag("input", $opt));
                    $tmp->writeln($sp.htmlspecialchars($item).$sp2);
                    $cnt++;
                }
            }
            $tbl->insertData($buf->get(), array("colspan"=>4));

            break;

        case BUGBOARD_CUSTOM_FIELD_TYPE_RADIO:
            $values = explode("|", $param['possible_values']);

            $buf = new Html_Buffer;
            $tmp = new Html_Writer($buf);
            $sp  = "&nbsp;";
            $sp2 = str_repeat($sp,2);
            
            foreach($values as $value) {

                if ($value == "") {
                    $tmp->writebr();
                }
                else {
                    $opt = array("type"=>"radio",
                                 "name"=>"__custom_field_".$param['id'],
                                 "value"=> htmlspecialchars($value));
                    if ($value == $param['value']) {
                        array_push($opt, "checked");
                    }

                    $tmp->write(make_tag("input", $opt));
                    $tmp->writeln($sp.htmlspecialchars($value).$sp2);
                }
            }
            $tbl->insertData($buf->get(), array("colspan"=>4));
            break;

        case BUGBOARD_CUSTOM_FIELD_TYPE_TEXT:
            $tbl->insertData(make_tag_closed("textarea", array("name"=>"__custom_field_".$param['id'], "cols"=>80, "rows"=>8),
                                             htmlspecialchars($param['value'])),
                             array("colspan"=>4));
            break;
        }

        $tbl->endRow();
        $tbl->nextTile();
    }
}

// update
$tbl->insertBlankRow();
$tbl->beginRow();
$tbl->insertHeadBlank();
$str.= make_tag("input", array("type"=>"submit", "value"=>"��������"));
$tbl->insertData($str, array("colspan"=>4));
$tbl->endRow();

$tbl->endTable();

$content = $html.$tbl->to_html().'</form></div>';


print($content);
print(Bugboard_FooterTemplate());

?>

