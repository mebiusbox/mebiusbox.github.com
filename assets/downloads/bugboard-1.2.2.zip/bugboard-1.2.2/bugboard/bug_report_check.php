<?php
/**
 * @file
 * @brief ��ݡ������ƥ����å�����Ͽ
 * @author typezero
 */
?>
<?php
require_once("common.php");
require_once("gen_rss.php");

//------------------------------------------------------------

log_debug($_POST);

mb_convert_variables(BUGBOARD_INTERNAL_ENCODING, BUGBOARD_HTML_ENCODING, $_POST);

function filter_string($val) {
    return stripslashes(bugboard_mb_trim($val));
}

$in_param = array();
foreach ($_POST as $key=>$value) {
    $in_param[$key] = filter_string($value);
}

$t_summary = $in_param['summary'];
$t_body    = $in_param['body'];
$t_name    = $in_param['name'];

log_debug($in_param);

//------------------------------------------------------------


$_SESSION['form_values'] = $in_param;

$err = "";

if ($t_name == "") {
    $err .= " - ̾�������Ϥ��Ƥ���������<br>";
}

if ($t_summary == "") {
    $err .= " - ��������Ϥ��Ƥ���������<br>";
}

if ($t_body == "") {
    $err .= " - ���פ����Ϥ��Ƥ���������<br>";
}

if (BUGBOARD_ANTISPAM_A_TAG)
{
    // a ���������ä�������̵�Ѥǥ��ѥష��

    mb_regex_encoding(BUGBOARD_INTERNAL_ENCODING);
    if (mb_ereg("<a [ \r\n\t\w=\"]*href[ \r\n\t\w=\"]*>", $t_body)) {
        $err .= " - ���פ���Ŭ�ڤ�ʸ�Ϥ�����ޤ�";
    }
}

if ($err != "") {
    goto_error_page(lang_get('error', 'form_omission'), $err);
}

unset($_SESSION['form_values']);


//------------------------------------------------------------

$db  = &$db_;

$db->autoCommit();

$body_id = $db->nextId(BUGBOARD_BUG_TEXT_ID_SEQ);
$ret = $db->query("INSERT INTO ".BUGBOARD_BUG_TEXT_TABLE."(id,body) VALUES(?,?)",
                  array($body_id, $t_body));

$bug_id = $db->nextId(BUGBOARD_BUG_ID_SEQ);
$now = date("Y/m/d H:i:s");

$sql_gen = new Sql_Gen("INSERT", BUGBOARD_BUG_TABLE);
$sql_gen->set_field(array("id", "summary", "body_id", "category",
                          "severity", "status",
                          "date_submitted", "reporter",
                          "last_updated", "last_updater", "vote_count"));
$ret = $db->query($sql_gen->gen_insert_placeholder(),
                  array($bug_id, $t_summary, $body_id, 
                        $in_param['category'], $in_param['severity'],
                        BUGBOARD_BUG_STATUS_NEW,
                        $now, $t_name,
                        $now, $t_name, 0));



// custom fileds
$cf_array = array();
foreach ($in_param as $key=>$value) {
    if (mb_ereg("(__custom_field_)([0-9]+)", $key, $m)) {
        if (empty($cf_array[ $m[2] ])) {
            $cf_array[ $m[2] ] = $value;
        }
        else {
            $cf_array[ $m[2] ] .= '|'.$value;
        }
    }
}

foreach ($cf_array as $key=>$value) {
    $ret = $db->query("INSERT INTO ".BUGBOARD_CUSTOM_FIELD_STRING_TABLE."(fid,bid,value) VALUES(?,?,?)",
                      array($key, $bug_id, $value));
}

/*
foreach ($in_param as $key=>$value) {
    if (mb_ereg("(__custom_field_)(\d+)", $key, $m)) {
        
        $ret = $db->query("INSERT INTO bugboard_custom_field_string_table(fid,bid,value) VALUES(?,?,?)",
                          array($m[2], $bug_id, $value));
    }
}
*/

// attach files
if (!empty($_FILES['attach_file']['name'])) {

    $attach_file_name = mb_convert_encoding($_FILES['attach_file']['name'],
                                            BUGBOARD_INTERNAL_ENCODING,
                                            BUGBOARD_HTML_ENCODING);
    $attach_file_comment = $attach_file_comment;
    
    $upload_dir = './attach/';
    do {
        $tmp = $upload_dir.md5(uniqid(mt_rand(),TRUE));
    } while (file_exists($tmp));

    if (move_uploaded_file($_FILES['attach_file']['tmp_name'], $tmp) == false) {
        $db->rollback();
        goto_error_page("��ݡ��� > ��Ͽ > ź�եե��������¸�˼���");
    }

    $attach_id = $db->nextId(BUGBOARD_BUG_FILE_ID_SEQ);
    $fields = "id,bid,diskfile,filename,folder,filesize,file_type,date_added";
    $ret = $db->query("INSERT INTO ".BUGBOARD_BUG_FILE_TABLE."(".$fileds.") VALUES(?,?,?,?, ?,?,?,?)",
                      array($attach_id, $bug_id,
                            $tmp,
                            $attach_file_name,
                            $upload_dir,
                            $_FILES['attach_file']['size'],
                            $_FILES['attach_file']['type'],
                            $now));

    log_debug("==================== attach file");
    log_debug("   name: ".$attach_file_name);
    log_debug("   size: ".$_FILES['attach_file']['size']);
    log_debug("   type: ".$_FILES['attach_file']['type']);
    log_debug("==================== attach file end");
}

$db->commit();

gen_rss($db);

if (BUGBOARD_MAIL_NOTIFICATION && in_array('add_report', $bugboard_mail_notification_event_list)) {

    $summary = $t_summary;
    $summary = mb_convert_kana($summary);
    $summary = htmlspecialchars($summary);

    $name    = mb_convert_kana($t_name);
    $name    = htmlspecialchars($name);

    $body    = mb_convert_kana($t_body);
    $body    = htmlspecialchars($body);

    bugboard_send_mail(
        array(
            'email_list' => $bugboard_mail_notification_email_list,
            'from' => BUGBOARD_MAIL_NOTIFICATION_SENDER,
            'subject' => $summary.' by '.$name,
            'body' => $body,
            'cc_list' => $bugboard_mail_notification_cc_list,
            'bcc_list' => $bugboard_mail_notification_bcc_list));
}

log_debug("�����׵� > ��Ͽ > ����");

Header("Location: index.php");
?>

