<?php
/**
 * @file
 * @brief ����������ܤ��Խ�������
 * @author typezero
 */
?>
<?php
require_once("common.php");

// �����������������å�
if (empty($_POST) || empty($_POST['acttype'])) {
    goto_error_page(lang_get('error', 'illegal_access'));
}

// ���������������¥����å�
if (empty($_SESSION['admin'])) {
    goto_error_page(lang_get('error', 'illegal_access_level'));
}

//------------------------------------------------------------


$loc = "manage_custom_field.php";
$db  = &$db_;

if ($_POST['acttype'] == 'new') {
    //------------------------------------------------------------
    //          acttype : new
    //------------------------------------------------------------
    
    $cf_name = bugboard_mb_trim($_POST['name']);
    if ($cf_name == "") {
        goto_error_page(lang_get('error', 'form_error'),
                                   lang_get('error', 'form_custom_field_name_invalid'));
    }

    $seq = $db->getOne("SELECT COUNT(*) FROM ".BUGBOARD_CUSTOM_FIELD_TABLE);
    $fid = $db->nextId(BUGBOARD_CUSTOM_FIELD_ID_SEQ);
    $sql  = "INSERT INTO ".BUGBOARD_CUSTOM_FIELD_TABLE;
    $sql .= "(id, name, description, type, possible_values, default_value, seq)";
    $sql .= " VALUES(?,?,?,?,?,?,?)";
    
    $db->query($sql, array($fid, $cf_name, "", BUGBOARD_CUSTOM_FIELD_TYPE_STRING, "", "", $seq));
    
    $loc = "manage_custom_field_edit.php?fid=".$fid;
}
elseif ($_POST['acttype'] == 'update') {
    //------------------------------------------------------------
    //          acttype : update
    //------------------------------------------------------------

    // �����������̵ͭ�����å�
    if (is_custom_field_exists($db_, $_POST['fid']) == false) {
        goto_error_page(lang_get('error', 'custom_field_not_found'));
    }

    $cf_name = bugboard_mb_trim($_POST['name']);
    if ($cf_name == "") {
        goto_error_page(lang_get('error', 'form_error'),
                                   lang_get('error', 'form_custom_field_name_invalid'));
    }

    $possible_values = explode("|", $_POST['possible_values']);
    $default_value   = bugboard_mb_trim($_POST['default_value']);

    // ����ζ������
    $trimmer = create_function('$val', 'return bugboard_mb_trim($val);');
    $possible_values = array_map($trimmer, $possible_values);

    $err = "";

    switch ($_POST['type']) {
    case BUGBOARD_CUSTOM_FIELD_TYPE_LIST:
    case BUGBOARD_CUSTOM_FIELD_TYPE_RADIO:
        if (implode("", $possible_values) == "") {
            $err .= lang_get('error', 'form_possible_values_invalid').'<br>';
        }
        if ($default_value == "") {
            $err .= lang_get('error', 'form_default_value_invalid').'<br>';
        }
        elseif (in_array($default_value, $possible_values) == false) {
            $err .= lang_get('error', 'form_default_value_invalid').'<br>';
        }
        break;
        
    case BUGBOARD_CUSTOM_FIELD_TYPE_CHECKBOX:
        if (implode("", $possible_values) == "") {
            $err .= lang_get('error', 'form_possible_values_invalid').'<br>';
        }

        $default_values = explode("|", $default_value);
        $default_values = array_map($trimmer, $default_values);
        foreach ($default_values as $val) {
            if (in_array($val, $possible_values) == false) {
                $err .= lang_get('error', 'form_default_value_invalid').'<br>';
                break;
            }
        }

        $default_value = implode("|", $default_values);
        
        break;
    }

    if ($err != "") {
        goto_error_page(lang_get('error', 'form_error'), $err);
    }

    
    $sql  = "UPDATE ".BUGBOARD_CUSTOM_FIELD_TABLE;
    $sql .= " SET name=?,description=?,type=?,possible_values=?,default_value=?";
    $sql .= " WHERE id=?";
    $db->query($sql,
               array($cf_name, $_POST['description'], $_POST['type'],
                     implode("|", $possible_values), $default_value,
                     $_POST['fid']));
}
elseif ($_POST['acttype'] == 'delete') {
    //------------------------------------------------------------
    //          acttype : delete
    //------------------------------------------------------------

    // �����������������å�
    if (empty($_POST['fid'])) {
        goto_error_page(lang_get('error', 'illegal_access'));
    }
    
    // �����������̵ͭ�����å�
    if (is_custom_field_exists($db_, $_POST['fid']) == false) {
        goto_error_page(lang_get('error', 'custom_field_not_found'));
    }

    $db->autoCommit();
    // �ǡ���
    $db->query("DELETE FROM ".BUGBOARD_CUSTOM_FIELD_STRING_TABLE." WHERE fid=?",
               arraY($_POST['fid']));
    // ����
    $db->query("DELETE FROM ".BUGBOARD_CUSTOM_FIELD_TABLE." WHERE id=?",
               array($_POST['fid']));
    $db->commit();
}
elseif ($_POST['acttype'] == 'sort') {
    //------------------------------------------------------------
    //          acttype : sort
    //------------------------------------------------------------

    $db->autoCommit();

    while (list($key,$var) = each($_POST)) {
        if (ereg("seq_([0-9]+)$",$key,$match)) {
            $db->query("UPDATE ".BUGBOARD_CUSTOM_FIELD_TABLE." SET seq=? WHERE id=?",
                     array($var, $match[1]));
        }
    }
    
    $db->commit();
}

Header("Location:".$loc);

?>
