/**
 * @file 
 * @brief grid
 * @author typezero
 */

/*
startHighlight = function()
{
    if (document.all && document.getElementById) {
        
        navRoot = document.getElementById("selectbox");
		if (navRoot) {

        tbody = navRoot.childNodes[0];
        
        for (i=0; i<tbody.childNodes.length; i++) {
            
            if (tbody.childNodes[i].nodeName == "TR") {
                
                tbody.childNodes[i].onmouseover=function()
                {
                    if (this.className.indexOf("grid",0) != -1) {
                        this.className = this.className.concat("_hover");
                    }
                }

                tbody.childNodes[i].onmouseout=function()
                {
                    if (this.className.indexOf("grid",0) != -1) {
                        this.className = this.className.replace("_hover","");
                    }
                }
            }
        }
        }
    }
}

startHighlight2 = function()
{
    if (document.all && document.getElementsByTagName) {

		var tables = document.getElementsByTagName('table');
		for (i=0; i<tables.length; i++) {

			if (tables[i].className == 'selectbox') {
				var tbody = tables[i].childNodes[0];
				
				for (j=0; j<tbody.childNodes.length; j++) {
					if (tbody.childNodes[j].nodeName == "TR" &&
						tbody.childNodes[j].className.indexOf("grid",0) != -1) {

                tbody.childNodes[j].onmouseover=function()
                {
                    this.className = this.className.concat("_hover");
                }

                tbody.childNodes[j].onmouseout=function()
                {
                    this.className = this.className.replace("_hover","");
                }
					}
				}
            }
        }
    }
}

window.onload = startHighlight;
*/

function on_grid_over(id) {

  if (document.all && document.getElementById) {
    obj = document.getElementById(id);
    if (obj) {
       if (obj.className.indexOf("grid",0) != -1) {
         obj.className = obj.className.concat("_hover");
       }
    }
  }
}

function on_grid_out(id) {

  if (document.all && document.getElementById) {
    obj = document.getElementById(id);
    if (obj) {
       if (obj.className.indexOf("grid",0) != -1) {
         obj.className = obj.className.replace("_hover", "");
       }
    }
  }
}

