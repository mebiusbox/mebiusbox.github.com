<?php
/**
 * @file 
 * @brief
 * @author typezero
 */
?>
<?php

function Bugboard_ViewTemplateFilter($mode, &$content) {
    $ret = "";
    $ret .= '<div class="sub_contents">';
    $ret .= '<div class="sub_title">�ե��륿��</div>';
    $ret .= '<form action="index.php?apply&amp;mode='.$mode.'" method="post">';
    $ret .= $content;
    $ret .= '</form>';
    $ret .= '</div>';
    return $ret;
}

function Bugboard_ViewTemplateStatus(&$content) {
    $ret = "";
    $ret .= '<div class="sub_contents">';
    $ret .= '<div class="mgn1">';
    $ret .= $content;
    $ret .= '</div></div>';
    return $ret;
}

function Bugboard_ViewTemplateMenu($listmode, $listmode_name, $curmode) {
    $ret = "";
    $ret .= '<table width="100%"><tr><td align="center">';
    $ret .= '<span class="small"><a class="menulist" href="bug_report.php" target="_blank">�������</a></span>';
    $ret .= '&nbsp;|&nbsp;';
    $ret .= '<span class="small"><a class="menulist" href="index.php?refresh&amp;mode='.$listmode.'">'.$listmode_name.'</a></span>';
    $ret .= '&nbsp;|&nbsp;';
    $ret .= '<span class="small"><a class="menulist" href="index.php?refresh&amp;mode='.$curmode.'">����</a></span>';
    $ret .= '</td></tr></table>';
    return $ret;
}

function Bugboard_ViewTemplateList($content) {
    $ret = "";
    $ret .= '<div class="sub_contents">';
    $ret .= $content;
    $ret .= '</div>';
    return $ret;
}

?>