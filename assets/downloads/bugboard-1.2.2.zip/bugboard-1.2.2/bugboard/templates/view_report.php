<?php
/**
 * @file 
 * @brief
 * @author typezero
 */
?>
<?php


function Bugboard_ViewTemplateCmdbar($dummy, $enables=array()) {
    $ret = "";
    $ret .= '<div class="sub_contents">';
    $ret .= '<table width="100%" class="accessbar"><tr><td align="center">';
    if (isset($enables) && in_array("comment", $enables)) {
        $ret .= '|&nbsp;<a href="#comment">������</a>';
    }
    if (isset($enables) && in_array("edit", $enables)) {
        $ret .= '|&nbsp;<a href="#resolve">�������</a>';
    }
    if (isset($enables) && in_array("vote", $enables)) {
        $ret .= '|&nbsp;<a href="#vote">��ɼ</a>';
    }
    if (isset($enables) && count($enables)>0) {
        $ret .= '&nbsp;|';
    }
    $ret .= '</td></tr></table>';
    $ret .= '</div>';
    return $ret;
}

function Bugboard_ViewTemplateBody($content) {
    $ret  = "";
    $ret .= '<div class="sub_contents">';
    $ret .= '<div class="sub_title">��ݡ�������</div>';
    $ret .= $content;
    $ret .= '</div>';
    return $ret;
}


function Bugboard_ViewTemplateAttachFile($bid, $content) {
    $ret  = "";
    $ret .= '<div class="sub_contents">';
    $ret .= '<div class="sub_title"><a class="local" name="add_file">�ե������ɲ�</a></div>';
    $ret .= '<form action="bug_report_action.php?bid='.$bid.'" method="post" enctype="multipart/form-data" name="attach_form" onSubmit="return attach_form_check()">';
    $ret .= '<input type="hidden" name="acttype" value="add_file" />';
    $ret .= '<input type="hidden" name="MAX_FILE_SIZE" value="2000000" />';
    $ret .= $content;
    $ret .= '</form>';
    $ret .= '</div>';
    return $ret;
}

function Bugboard_ViewTemplateComment($content) {
    $ret  = "";
    $ret .= '<div class="sub_contents">';
    $ret .= '<div class="sub_title"><a class="local" name="comment">������</a></div>';
    $ret .= $content;
    $ret .= '</div>';
    return $ret;
}

function Bugboard_ViewTemplateAddComment($bid, $content) {
    $ret  = "";
    $ret .= '<div class="sub_contents">';
    $ret .= '<div class="sub_title"><a class="local" name="add_comment">�������ɲ�</a></div>';
    $ret .= '<form action="bug_report_action.php?bid='.$bid.'" method="post" name="comment_form" onSubmit="return comment_form_check()">';
    $ret .= '<input type="hidden" name="acttype" value="comment_add" />';
    $ret .= $content;
    $ret .= '</form>';
    $ret .= '</div>';
    return $ret;
}

function Bugboard_ViewTemplateEdit($bid) {
    $ret  = "";
    $ret .= '<div class="sub_contents">';
    $ret .= '<div class="sub_title"><a class="local" name="resolve">�������</a></div>';
    $ret .= '<div class="component">';
    $ret .= '<form action="bug_report_action.php?bid='.$bid.'" method="post">';
    $ret .= '<input type="hidden" name="acttype" value="resolve" />';
    $ret .= '<input type="submit" name="checked" value="�����Ƴ�ǧ�ѡ�" />&nbsp;';
    $ret .= '<input type="submit" name="feedback" value="�����ɲþ���" />&nbsp;';
    $ret .= '<input type="submit" name="start" value="����ꡡ" />&nbsp;';
    $ret .= '<input type="submit" name="notrepro" value="���Ƹ����褺��" />&nbsp;';
    $ret .= '<input type="submit" name="fixed" value="�������Ѥߡ�" />&nbsp;';
    $ret .= '<input type="submit" name="suspend" value="����α��" />&nbsp;';
    $ret .= '<input type="submit" name="rejected" value="���Ѳ���" />&nbsp;';
    $ret .= '<input type="submit" name="closed" value="����λ��" />&nbsp;';
    $ret .= '</form>';
    $ret .= '</div></div>';
    return $ret;
}

function Bugboard_ViewTemplateVote($bid) {
    $ret  = "";
    $ret .= '<div class="sub_contents">';
    $ret .= '<div class="sub_title"><a class="local" name="vote">��ɼ</a></div>';
    $ret .= '<div class="component">';
    $ret .= '���Υ�ݡ��ȤˤĤ��ơ����ʤ����б���˾�������ɼ���Ƥ���������';
    $ret .= '��ȯ�ԤϤ�����ɼ�򻲹ͤˤ���ͥ����������뤳�Ȥ�����ޤ���';
    $ret .= '&nbsp;';
    $ret .= '<form action="bug_report_action.php?bid='.$bid.'" method="post">';
    $ret .= '<input type="hidden" name="acttype" value="vote" />';
    $ret .= '<input type="submit" value="����ɼ��" />';
    $ret .= '</form>';
    $ret .= '</div></div>';
    return $ret;
}

function Bugboard_ViewTemplateDelete($bid) {
    $ret  = "";
    $ret .= '<br />';
    $ret .= '<br />';
    $ret .= '<br />';
    $ret .= '<br />';
    $ret .= '<br />';
    $ret .= '<div class="sub_contents"><div class="component" style="text-align:center">';
    $ret .= '<form action="bug_report_delete.php?bid='.$bid.'" method="post">';
    $ret .= '<input type="submit" value="�������" />';
    $ret .= '</form>';
    $ret .= '</div></div>';
    return $ret;
}

?>