<?php
/**
 * @file 
 * @brief
 * @author typezero
 */
?>
<?

/**
 * @brief
 * @param[in]
 * @param[in]
 */
function Bugboard_HeaderTemplate($ext=NULL) {
    $ret = "";
    $ret .= '<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">';
    $ret .= '<html>';
    $ret .= '<head>';
    $ret .= '<meta http-equiv="Content-Type" content="text/html; charset='.BUGBOARD_HTML_CHARSET.'">';
    $ret .= '<meta http-equiv="Content-Style-Type" content="text/css">';
    $ret .= '<meta http-equiv="Content-Script-Type" content="text/javascript">';
    $ret .= '<title>'.PROJECT_NAME.' - Bugboard '.BUGBOARD_VERSION.' (Bug Tracking System)</title>';
    $ret .= '<script type="text/javascript" src="./javascript/grid.js"></script>';
    $ret .= '<link rel="stylesheet" type="text/css" href="./css/bugboard.css">';

    if (BUGBOARD_GENERATE_RSS) {
        $ret .= '<link rel="alternate" type="application/rss+xml" title="'.PROJECT_NAME.' - Bugboard" href="./rss/?feed=rss">';
        $ret .= '<link rel="alternate" type="application/rss+xml" title="'.PROJECT_NAME.' - Bugboard Comments" href="./rss/?feed=comments-rss">';
    }

    if (isset($ext)) {
        $ret .= '<!-- head_ext -->';
        $ret .= $ext;
    }
    
    $ret .= '</head>';
    $ret .= '<body>';
    $ret .= '<table width="100%" border="0" cellpadding="0" cellspacing="0">';
    $ret .= '<tr><td class="header">';
    $ret .= '<span class="project_title">'.PROJECT_NAME.'</span>';
    $ret .= '<span class="bugboard_title"> - Bugboard '.BUGBOARD_VERSION.' (Bug Tracking System)</span></td></tr>';
    $ret .= '<tr><td><div class="container">';

    return $ret;
};

/**
 * @brief
 * @param[in]
 */
function Bugboard_FooterTemplate() {
    $ret = "";
    $ret .= '</div></td></tr>';
    $ret .= '<tr><td class="footer">';
    $ret .= '<hr size="1">';
    $ret .= '&copy; 2007-2008 mebiusbox software.';
    $ret .= '</td></tr></table>';
    $ret .= '</body>';
    $ret .= '</html>';
    return $ret;
}

/**
 * @brief
 * @param[in]
 * @param[in]
 * @param[in]
 */
function Bugboard_InfoboxTemplate($caption="", $summary="", $comment=NULL) {
    $ret = "";
    $ret .= '<div class="info_box">';
    $ret .= '<table class="info_box" border="0" cellspacing="0" cellpadding="0">';
    $ret .= '<tr><th>'.$caption.'</th></tr>';
    $ret .= '<tr><td class="summary" align="center" nowrap>'.$summary.'</td></tr>';
    if (isset($comment)) {
        $ret .= '<tr><td class="comment">'.$comment.'</td></tr>';
    }
    $ret .= '</table>';
    $ret .= '</div>';
    return $ret;
}

/**
 * @brief
 * @param[in]
 * @param[in]
 */
function Bugboard_ErrorboxTemplate($err="", $comment=NULL) {
    $ret = "";
    $ret .= '<div class="error_box">';
    $ret .= '<table class="error_box" border="0" cellspacing="0" cellpadding="0">';
    $ret .= '<tr><th>���顼</th></tr>';
    $ret .= '<tr><td class="summary" align="center" nowrap>'.$err.'</td></tr>';

    if (isset($comment)) {
        $ret .= '<tr><td class="comment">'.$comment.'</td></tr>';
    }
    
    $ret .= '</table>';
    $ret .= '</div>';
    return $ret;
}

/**
 * @brief
 * @param[in]
 */
function Bugboard_LoginTemplate($err=NULL) {
    $ret = "";
    if (isset($err)) {
        $ret .= '<div style="padding-top:32px;color:#ff0000;text-align:center">'.$err.'</div>';
    }
    $ret .= '<div class="login_box">';
    $ret .= '<form method="post" action="login.php">';
    $ret .= '<table class="listbox" style="border:1px solid #000000" border="0">';
    $ret .= '<tr class="grid_odd">';
    $ret .= '<th align="right">�桼��ID</th>';
    $ret .= '<td><input type="text" name="username" size="20" maxlength="32" style="ime-mode:disabled" /></td>';
    $ret .= '</tr>';
    $ret .= '<tr class="grid_even">';
    $ret .= '<th align="right">�ѥ����</th>';
    $ret .= '<td><input type="password" name="password" size="20" maxlength="32" /></td>';
    $ret .= '</tr>';
    $ret .= '<tr>';
    $ret .= '<td colspan="2" align="center"><input type="submit" name="submit" value="��Login��" /></td>';
    $ret .= '</tr>';
    $ret .= '</table></form></div>';
    $ret .= '<div style="width:100%;text-align:center">[&nbsp;<a class="menulist" href="index.php">���</a>&nbsp;]</div>';
    return $ret;
}

/**
 * @brief
 * @param[in]
 * @return
 */
function Bugboard_AdminTemplate($cmds) {
    $ret = "";
    $ret .= '<table style="width:98%" cellspacing="0" cellpadding="0" border="0">';
    $ret .= '<tr><td align="right">'.$cmds.'</td></tr>';
    $ret .= '</table>';
    return $ret;
}


?>