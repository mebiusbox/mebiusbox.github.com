<?php
/**
 * @file
 * @brief �桼������������ȴ���
 * @author typezero
 */
?>
<?php
require_once("common.php");


// ���������������¥����å�
if (empty($_SESSION['admin'])) {
    goto_error_page(lang_get('error', 'illegal_access_level'));
}


//------------------------------------------------------------

print(Bugboard_HeaderTemplate(
    Bugboard_user_form_check_js()));
print(Bugboard_AdminTemplate(make_admin_commands()));


//------------------------------------------------------------


$html = '<div class="sub_contents">';
$html.= '<div class="sub_title">��������Ȥκ���</div>';

$html .= make_tag("form",
                  array("action"=>"manage_user_action.php",
                        "method"=>"post",
                        "name"=>"user_create_form",
                        "onSubmit"=>"return user_create_form_check()"));
$html .= make_input_tag("hidden", "act", "create");
$tbl = new Gull_Table_Html(array("class"=>"listbox"));
$tbl->setInterlaceMode(true);

$tbl->beginRow();
$tbl->insertHead(FORM_REQUIRED_MARK.lang_get('user_name'), array("style"=>"width:20%"));
$tbl->insertData(make_tag("input",
                          array("type"=>"text",
                                "name"=>"name",
                                "size"=>30,
                                "maxlength"=>32)));
$tbl->endRow();

$tbl->beginRow();
$tbl->insertHead(FORM_REQUIRED_MARK.lang_get('password'));
$tbl->insertData(make_tag("input",
                          array("type"=>"password",
                                "name"=>"pass",
                                "size"=>30,
                                "maxlength"=>32))."&nbsp;(�ѿ����Τ�)");
$tbl->endRow();

$tbl->beginRow();
$tbl->insertHead(lang_get('real_name'));
$tbl->insertData(make_tag("input",
                          array("type"=>"text",
                                "name"=>"nickname",
                                "size"=>30,
                                "maxlength"=>32)));
$tbl->endRow();

$tbl->beginRow();
$tbl->insertHeadBlank();
$tbl->insertData(make_tag("input",
                           array("type"=>"submit",
                                 "value"=>lang_get('create_button'))).'&nbsp;'.FORM_REQUIRED_MARK.lang_get('require_form_item'));
$tbl->endRow();
$tbl->endTable();

$html .= $tbl->to_html();
$html .= '</form></div>';


$html .= '<div class="sub_contents">';
$html.= '<div class="sub_title">�桼������������Ȱ���</div>';

$tbl = new Gull_Table_Html(array("class"=>"selectbox", "id"=>"selectbox"));
$tbl->beginRow();
$tbl->insertHeadCenter("�桼����̾",   array("id"=>"width100px"));
$tbl->insertHeadCenter("�˥å��͡���", array("id"=>"width100px"));
$tbl->insertHeadBlank();
$tbl->endRow();
$tbl->setInterlaceMode(true);

$db = &$db_;
$stt = "SELECT * FROM ".BUGBOARD_USER_TABLE;
$rs = $db->query($stt);
while ($row = $rs->fetchRow(DB_FETCHMODE_ASSOC)) {

    $tbl->beginRow();
    $tbl->insertData($row['name']);
    $tbl->insertData($row['nickname']);

    $tag = make_tag("form",
                    array("action"=>"manage_user_action.php",
                          "method"=>"post"));
    $tag .= make_input_tag("hidden", "act", "delete");
    $tag .= make_input_tag("hidden", "uid", $row['id']);
    $tag .= make_input_tag("submit", "delete", "���");
    $tag .= "</form>";
    $tbl->insertData($tag);
    $tbl->endRow();
}
$tbl->endTable();

$html .= $tbl->to_html();
$html .= '</div>';


//------------------------------------------------------------

print($html);
print(Bugboard_FooterTemplate());

?>