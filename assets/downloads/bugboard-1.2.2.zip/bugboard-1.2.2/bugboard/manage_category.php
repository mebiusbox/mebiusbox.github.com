<?php
/**
 * @file
 * @brief ����������ܴ���
 * @author typezero
 */
?>
<?php
require_once("common.php");


// ���������������¥����å�
if (empty($_SESSION['admin'])) {
    goto_error_page(lang_get('error', 'illegal_access_level'));
}


//------------------------------------------------------------

print(Bugboard_HeaderTemplate(
    Bugboard_category_form_check_js()));
print(Bugboard_AdminTemplate(make_admin_commands()));

//------------------------------------------------------------

$db = &$db_;
$rs = $db->query("SELECT * FROM ".BUGBOARD_CATEGORY_TABLE);

$contents = array();

$html = new Html_BufferedWriter();
$html->writeln('<div class="sub_contents">');
$html->writeln('<div class="sub_title">���ƥ���ο�������</div>');
$html->writeln('<div class="component">');
$html->writeln(make_tag("form",
                  array("action"=>"manage_category_edit_action.php",
                        "method"=>"post",
                        "name"=>"add_category_form",
                        "onSubmit"=>"return add_category_form_check()")));
$html->writeln('<input type="hidden" name="acttype" value="add_category">');
$html->writeln('<input type="text" name="name" size="40" maxlength="255">');
$html->writeln("&nbsp;".'<input type="submit" value="��������">');
$html->writeln('</form>');
$html->writeln('</div></div>');
print($html->get());

//------------------------------------------------------------

$html = new Html_BufferedWriter();
$html->writeln('<div class="sub_contents">');
$html->writeln('<div class="sub_title">���ƥ������</div>');
print($html->get());

$tbl = new Gull_Table_Html(array("class"=>"listbox"));
$tbl->beginRow();
$tbl->insertHeadCenter("���ƥ���̾");
$tbl->endRow();
$tbl->setInterlaceMode(true);

while ($row = $rs->fetchRow(DB_FETCHMODE_ASSOC)) {
    $tbl->beginRow();

    $tmp = make_tag("form",
                    array("action"=>"manage_category_edit_action.php",
                          "method"=>"post"));
    $tmp .= make_input_tag("hidden", "cid", $row['id']);
    $tmp .= make_input_tag("text", "name", $row['category'],
                           array("size"=>80, "maxlength"=>255));
    $tmp .= "&nbsp;&nbsp;";
    $tmp .= make_input_tag("submit", "rename", "�ѹ�");
    $tmp .= "&nbsp;";
    $tmp .= make_input_tag("submit", "delete", "���");
    $tmp .= "</form>";
    $tbl->insertData($tmp);
    $tbl->endRow();
}
$tbl->endTable();
print($tbl->to_html());

$html = new Html_BufferedWriter();
$html->writeln('</form>');
$html->writeln('</div>');
print($html->get());

//------------------------------------------------------------

print(Bugboard_FooterTemplate());
?>

