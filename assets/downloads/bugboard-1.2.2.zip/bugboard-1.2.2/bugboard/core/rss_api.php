<?php
/**
 * @file 
 * @brief RSS 1.0 maker
 * @author typezero
 */
?>
<?php

/**
 */
class RssWriter {
    var $buf_ch    = "";
    var $buf_items = "";
    var $i_encoding  = "";
    var $user_xmlns = array();

    function RssWriter($i_encoding) {
        $this->i_encoding = $i_encoding;
    }

    function SetUserXmlns($xmlns) {
        $this->user_xmlns = $xmlns;
    }

    function WriteChannel($about, $title, $link, $description) {
        $this->buf_ch  = '<?xml version="1.0" encoding="utf-8" ?>'."\n";
        $this->buf_ch .= '<rdf:RDF'.$this->MakeXmlns().'>'."\n";
        $this->buf_ch .= '  <channel rdf:about="'.$about.'">'."\n";
        $this->buf_ch .= '    <title>'.$title.'</title>'."\n";
        $this->buf_ch .= '    <link>'.$link.'</link>'."\n";
        $this->buf_ch .= '    <description>'.$description.'</description>'."\n";
        $this->buf_ch .= '    <dc:date>'.date("Y-m-d\TH:i:s").'+09:00</dc:date>'."\n";
        $this->buf_ch .= '    <dc:language>ja</dc:language>'."\n";
        $this->buf_ch .= ''."\n";
        $this->buf_ch .= '    <items>'."\n";
        $this->buf_ch .= '      <rdf:Seq>'."\n";
    }

    function AddItem($about, $title, $link, $description, $params = array()) {
        $this->buf_items .= '  <item rdf:about="'.$about.'">'."\n";
        $this->buf_items .= '    <title>'.$title.'</title>'."\n";
        $this->buf_items .= '    <link>'.$link.'</link>'."\n";
        $this->buf_items .= '    <description>'.$description.'</description>'."\n";
        foreach ($params as $key => $value) {
            $this->buf_items .= '    <'.$key.'>'.$value.'</'.$key.'>'."\n";
        }
        $this->buf_items .= '  </item>'."\n";
        
        $this->buf_ch .= '        <rdf:li rdf:resource="'.$about.'" />'."\n";
    }

    function Gen() {
        $buf = $this->buf_ch;
        $buf .= '      </rdf:Seq>'."\n";
        $buf .= '    </items>'."\n";
        $buf .= '  </channel>'."\n";
        $buf .= "\n";
        $buf .= $this->buf_items;
        $buf .= '</rdf:RDF>'."\n";
        return mb_convert_encoding($buf, "UTF-8", $this->i_encoding);
    }

    function MakeXmlns() {
    
        $str = "";
        
        if (count($this->user_xmlns)) {
            foreach($this->user_xmlns as $item) {
                $str .= " ".$item;
            }
        } else {
            $str .= ' xmlns="http://purl.org/rss/1.0/"';
            $str .= ' xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"';
            $str .= ' xmlns:dc="http://purl.org/dc/elements/1.1/"';
            $str .= ' xml:lang="ja"';
        }
        
        return $str;
    }
}

?>