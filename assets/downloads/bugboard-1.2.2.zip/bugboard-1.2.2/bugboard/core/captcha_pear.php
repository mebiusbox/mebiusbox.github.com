<?php
require_once('../config.php');
require_once('Text/CAPTCHA.php');

$c = Text_CAPTCHA::factory('Image');
$retval = $c->init($bugboard_captcha_pear_options);
if (PEAR::isError($retval)) {
//    printf('Error initializing CAPTCHA: %s!', $retval->getMessage());
    exit;
}

$png = $c->getCAPTCHAAsPNG();
if (PEAR::isError($png)) {
//    echo 'Error generating CAPTCHA!';
//    echo $png->getMessage();
    exit;
}

session_start();
$_SESSION['code'] = $c->getPhrase();

header("Content-type: image/png");
echo $png;
?>