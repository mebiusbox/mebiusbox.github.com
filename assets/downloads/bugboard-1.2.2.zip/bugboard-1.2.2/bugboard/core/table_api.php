<?php
/**
 * @file 
 * @brief HTML Table utility
 * @author typezero
 */
?>
<?php

/**
 * @brief �ơ��֥��������饹
 */
class Gull_Table {

    var $tdi;
    var $td_tile;
    var $td_tile_center;
    var $interlace_mode;

    function Gull_Table($param = array()) {

        $this->tdi = 0;
        $this->tr_class_array = array('grid_odd', 'grid_even');
        $this->interlace_mode = false;

        if (empty($param['border'])) {
            $param['border'] = 0;
        }

        if (empty($param['cellspacing'])) {
            $param['cellspacing'] = 1;
        }
        
        if (empty($param['cellpadding'])) {
            $param['cellpadding'] = 2;
        }

        print make_tag("table", $param);
    }

    function setInterlaceMode($enable) {
        $this->interlace_mode = $enable;
    }

    function nextGrid() {
        $this->tdi = 1 - $this->tdi;
    }

    function nextTile() {
        $this->nextGrid();
    }

    function beginRow($param=array()) {
        if (empty($param['class'])) {
            $param['class'] = $this->tr_class_array[$this->tdi];
        }
        print(make_tag("tr", $param));
    }

    function endRow() {
        print("</tr>\n");

        if ($this->interlace_mode == true) {
            $this->nextTile();
        }
    }

    function insertBlankRow() {
        print(make_tag("tr", array("class"=>"grid_blank"))."<td></td></tr>");
    }

    function insertHead($str, $param=array()) {
        $param['class'] = "head";
        print(make_tag("td", $param).$str.'</td>');
    }
    
    function insertHeadCenter($str, $param=array()) {
        $param['class'] = 'head';
        $param['align'] = 'center';
        print(make_tag("td", $param).$str.'</td>');
    }
    
    function insertHeadBlank($param=array()) {
        $param['class'] = "head";
        print(make_tag("td", $param)."&nbsp;".'</td>');
    }

    function insertData($str, $param=array()) {
        print(make_tag("td", $param).$str.'</td>');
    }

    function insertDataCenter($str, $param=array()) {
        $param['align'] = 'center';
        print(make_tag("td", $param).$str.'</td>');
    }

    function insertDataBlank($param=array()) {
        if (empty($param['class'])) {
            $param['class'] = "grid_blank";
        }
        print(make_tag("td", $param)."&nbsp;"."</td>");
    }

    function endTable() {
        print("</table>\n");
    }
}

/**
 * @brief �ơ��֥��������饹�ʥХåե���󥰡�
 */
class Gull_Table_Html extends Gull_Table {

    function Gull_Table_Html($param=array()) {
        ob_start();
        $this->Gull_Table($param);
    }

    function to_html() {
        $html = ob_get_contents();
        ob_end_clean();
        return $html;
    }
}

?>