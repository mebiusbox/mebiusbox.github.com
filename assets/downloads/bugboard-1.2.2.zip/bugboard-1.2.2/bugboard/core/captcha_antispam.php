<?php
require_once("jpgraph/jpgraph_antispam.php");

session_start();

$spam = new AntiSpam();
$code = $spam->Rand(8);
if ($spam->Stroke() === false) {
    die('Could not generate image.');
}
$_SESSION['code'] = $code;
?>