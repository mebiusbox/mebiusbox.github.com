<?php
/**
 * @file
 * @brief �ӣѣ̴�Ϣ�Σ��У�
 * @author typezero
 */
?>
<?php

/**
 * @brief �ӣѣ�ʸ�������饹
 */
class Sql_Gen {

    var $type  = null;
    var $table = null;
    var $field = null;
    var $param = null;
    var $where = null;
    var $order = null;

    function set_type($p) {
        $this->type = $p;
    }

    function set_table($p) {
        $this->table = $p;
    }

    function set_field($p) {
        $this->field = $p;
    }

    function set_param($p) {
        $this->param = $p;
    }

    function set_where($p) {
        $this->where = $p;
    }

    function set_order($p) {
        $this->order = $p;
    }

    function Sql_Gen($type=null, $table=null) {
        $this->set_type($type);
        $this->set_table($table);
    }

    function gen() {

        if (is_null($this->type)) {
            return null;
        }
        
        switch ($this->type) {
        case 'SELECT': return $this->gen_select();
        case 'INSERT': return $this->gen_insert();
        case 'UPDATE': return $this->gen_update();
        case 'DELETE': return $this->gen_delete();
        }

        return null;
    }

    function gen_select() {
        if (is_null($this->table)) { return null; }

        if (is_null($this->field)) {
            $field = array("*");
        }
        else {
            $field = $this->field;
        }

        $sql = "SELECT ";
        $sql .= implode(',', $field);
        $sql .= " FROM ".$this->table;

        if (isset($this->where)) {
            $sql .= " WHERE ".$this->where;
        }

        if (isset($this->order)) {
            $sql .= " ORDER BY ".$this->order;
        }

        return $sql;
    }

    function gen_insert() {
        
        if (is_null($this->table)) { return null; }
        if (is_null($this->param)) { return null; }

        $sql  = "INSERT INTO ".$this->table."(";
        $sql .= implode(",", array_keys($this->param));
        $sql .= ") VALUES (";
        $sql .= implode(",", array_values($this->param));
        $sql .= ")";

        return $sql;
    }

    function gen_insert_placeholder() {
        
        if (is_null($this->table)) { return null; }
        if (is_null($this->field)) { return null; }

        $sql  = "INSERT INTO ".$this->table."(";
        $sql .= implode(",", $this->field);
        $sql .= ") VALUES (";
        $sql .= implode(",", array_fill(0, count($this->field), "?"));
        $sql .= ")";

        return $sql;
    }

    function gen_update() {

        if (is_null($this->table)) { return null; }
        if (is_null($this->param)) { return null; }

        $sql  = "UPDATE ".$this->table." SET ";
        $fields = array();
        
        foreach ($this->param as $key=>$value) {
            array_push($fields, $key."=".$value);
        }
        $sql .= implode(",", $fields);

        if (isset($this->where)) {
            $sql .= " WHERE ".$this->where;
        }

        return $sql;
    }

    function gen_delete() {

        if (is_null($this->table)) { return null; }

        $sql  = "DELETE FROM ".$this->table;
        
        if (isset($this->where)) {
            $sql .= " WHERE ".$this->where;
        }

        return $sql;
    }
}

/**
 * @brief SQL(SELECT)ʸ�������饹
 */
class Sql_Gen_Select extends Sql_Gen {

    function Sql_Gen_Select($table, $field=null, $where=null, $order=null) {
        parent::Sql_Gen("SELECT", $table);
        $this->set_field($field);
        $this->set_where($where);
        $this->set_order($order);
    }
}

?>