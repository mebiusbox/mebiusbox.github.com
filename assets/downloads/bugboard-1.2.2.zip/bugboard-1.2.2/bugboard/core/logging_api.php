<?php
/**
 * @file 
 * @brief ������
 * @author typezero
 */
?>
<?php

if (BUGBOARD_ENABLE_LOGGING) {
    require_once("Log.php");
}

function get_log_output_dir() {
    $base = dirname(__FILE__);
    return substr($base, 0, strrpos($base, DIRECTORY_SEPARATOR)+1)."log".DIRECTORY_SEPARATOR;
}

function log_debug($msg) {
    if (BUGBOARD_ENABLE_LOGGING) {
        $o_log = Log::factory("file", get_log_output_dir()."bugboard_".date("Ymd").".log", "bugboard");
        $o_log->log($msg, PEAR_LOG_DEBUG);
    }
}

function log_error($msg) {
    if (BUGBOARD_ENABLE_LOGGING) {
        $o_log = Log::factory("file", get_log_output_dir()."bugboard_".date("Ymd").".log", "bugboard");
        $o_log->log($msg, PEAR_LOG_ERR);
        exit(0);
    }
}

?>