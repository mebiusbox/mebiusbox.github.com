<?php
/**
 * @file 
 * @brief file api library.
 * @author typezero
 */
?>
<?php

/**
 */
function write_file($fname, $contents)
{
    $file = fopen($fname,"w");
    if ($file == FALSE) { return FALSE; }
    
    flock($file, LOCK_EX);
    ftruncate($file, 0);
    fputs($file, $contents);
    flock($file, LOCK_UN);
    fclose($file);
}

/**
 */
function read_file($fname)
{
    if (file_exists($fname) == FALSE) {
        log_debug("no file exists [".$fname."]");
        return "";
    }
    
    $file = fopen($fname, "r");
    if ($file == FALSE) {
        log_debug("could not open file [".$fname."]");
        return "";
    }

    $contents = "";
    while (!feof($file)) {
        $contents .= fgets($file);
    }
    fclose($file);
    
    return $contents;
}

?>