<?php
/**
 * @file 
 * @brief CAPTCHA api library.
 * @author typezero
 */
?>
<?php

/**
 */
function bugboard_captcha_is_enable()
{
    if (BUGBOARD_CAPTCHA_ANTI_SPAM) {
        return TRUE;
    }

    if (BUGBOARD_CAPTCHA_PEAR) {
        return TRUE;
    }

    if (BUGBOARD_CAPTCHA_KAW_TOMDS) {
        return TRUE;
    }

    if (BUGBOARD_CAPTCHA_PASSWORD) {
        return TRUE;
    }

    return FALSE;
}

/**
 */
function bugboard_captcha_url()
{
    if (BUGBOARD_CAPTCHA_ANTI_SPAM) {
        return "./core/captcha_antispam.php";;
    }

    if (BUGBOARD_CAPTCHA_PEAR) {
        return "./core/captcha_pear.php";
    }

    if (BUGBOARD_CAPTCHA_KAW_TOMDS) {
        srand((double)microtime() * 1000000);
        $_SESSION['code'] = rand(1,999999);
        return BUGBOARD_CAPTCHA_KAW_TOMDS_GRP;
    }

    if (BUGBOARD_CAPTCHA_PASSWORD) {
        $_SESSION['code'] = BUGBOARD_CAPTCHA_PASSWORD_PASSWORD;
        return "";
    }

    return "";
}

?>