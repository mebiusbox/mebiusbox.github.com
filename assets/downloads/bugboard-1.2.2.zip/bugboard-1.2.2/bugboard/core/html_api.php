<?php
/**
 * @file 
 * @brief Html tag utility
 * @author typezero
 */
?>
<?php

/**
 */
function make_tag($tag_name, $params = array()) {
    $tmp = "<".$tag_name;
    foreach ($params as $key => $value) {
        if ($key==null) {
            $tmp .= " ".$value;
        }
        else {
            $tmp .= " ".$key."=\"".$value."\"";
        }
    }
    $tmp.=">";
    return $tmp;
}

/**
 */
function make_tag_closed($tag_name, $params = array(), $body="") {
    
    return make_tag($tag_name, $params).$body."</".$tag_name.">";
}

/**
 */
function make_input_tag($type, $name, $value="", $checked=false) {

    $html = '<input type="'.$type.'" name="'.$name.'"';

    if ($value != "") {
        $html .= ' value="'.$value.'"';
    }
    if ($checked) {
        $html .= ' checked';
    }

    return $html.' />';
}

/**
 */
function make_select_tag($values, $selected = null, $params = array()) {
    $tmp = make_tag("select", $params);
    if (isset($values)) {
    foreach ($values as $key => $value) {

        if (isset($selected) && $key == $selected) {
            $tmp.= "<option value=\"".$key."\" selected>".$value."</option>";
        }
        else {
            $tmp.= "<option value=\"".$key."\">".$value."</option>";
        }
    }
    }
    $tmp.="</select>";
    return $tmp;
}

/**
 */
function make_select_tag2($items, $selected = null, $params = array()) {
    $tmp = make_tag("select", $params);
    if (isset($items)) {
    foreach ($items as $item) {

        if (isset($selected) && $item == $selected) {
            $tmp.= "<option value=\"".$item[0]."\" selected>".$item[1]."</option>";
        }
        else {
            $tmp.= "<option value=\"".$item[0]."\">".$item[1]."</option>";
        }
    }
    }
    $tmp.="</select>";
    return $tmp;
}

/**
 */
function make_script_tag($src) {
    $tmp = make_tag_closed("script",
                           array("type"=>"text/javascript",
                                  "src"=>$src));
    return $tmp;
}

/**
 */
function noscript($html) {
    return '<noscript>'.$html.'</noscript>';
}

/**
 */
class Html_Stream {
    function write($str) {
        print($str);
    }
}

/**
 */
class Html_Buffer {
    var $buf = "";
    
    function Html_Buffer() {
        $this->buf = "";
    }

    function write($str) {
        $this->buf .= $str;
    }

    function clear() {
        $this->buf = "";
    }

    function get() {
        return $this->buf;
    }
}

/**
 * @brief
 */
class Html_Writer {
    var $stream = null;

    function Html_Writer($stream=null) {
        if (is_null($stream)) {
            $this->stream = new Html_Stream;
        }
        else {
            $this->stream = $stream;
        }
    }

    function write($str) {
        $this->stream->write($str);
    }

    function writeln($str="") {
        $this->stream->write($str."\n");
    }

    function writebr($str="") {
        $this->stream->write($str.'<br>');
    }
}

/**
 * @brief
 */
class Html_BufferedWriter {
    var $buf = "";

    function Html_BufferedWriter() {
    }

    function write($str) {
        $this->buf .= $str;
    }

    function writeln($str="") {
        $this->buf .= $str."\n";
    }

    function writebr($str="") {
        $this->buf .= $str.'<br>';
    }

    function get() {
        return $this->buf;
    }
}

?>