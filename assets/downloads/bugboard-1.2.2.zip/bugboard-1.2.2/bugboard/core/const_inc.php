<?php
/**
 * @file 
 * @brief constants
 * @author typezero
 */
?>
<?php

define("BUGBOARD_VERSION", "1.2.2");

define("BUGBOARD_TRUE",  1);
define("BUGBOARD_FALSE", 0);

define("BUGBOARD_INTERNAL_ENCODING", "EUC-JP");

define("BUGBOARD_ENABLE_LOGGING", FALSE);

define("BUGBOARD_STEP_ERROR", -1);
define("BUGBOARD_STEP_LOGIN", 0);
define("BUGBOARD_STEP_READY", 1);

// bugboard_user_table
define("BUGBOARD_USER_NULL", 0);

// bugboard_bug_table - severity
define("BUGBOARD_BUG_SEVERITY_CRITICAL",    1);
define("BUGBOARD_BUG_SEVERITY_ERROR",       2);
define("BUGBOARD_BUG_SEVERITY_MAJOR",       3);
define("BUGBOARD_BUG_SEVERITY_MINOR",       4);
define("BUGBOARD_BUG_SEVERITY_ENHANCEMENT", 5);

// butboard_bug_table - status
define("BUGBOARD_BUG_STATUS_NEW",       1);
define("BUGBOARD_BUG_STATUS_START",     2);
define("BUGBOARD_BUG_STATUS_NOTREPRO",  3);
define("BUGBOARD_BUG_STATUS_FIXED",     4);
define("BUGBOARD_BUG_STATUS_SUSPEND",   5);
define("BUGBOARD_BUG_STATUS_REJECTED",  6);
define("BUGBOARD_BUG_STATUS_CLOSED",    7);
define("BUGBOARD_BUG_STATUS_FEEDBACK",  8);
define("BUGBOARD_BUG_STATUS_CHECKED",   9);

// bugboard_custom_field_table - type
define("BUGBOARD_CUSTOM_FIELD_TYPE_STRING",   0);
define("BUGBOARD_CUSTOM_FIELD_TYPE_LIST",     1);
define("BUGBOARD_CUSTOM_FIELD_TYPE_CHECKBOX", 2);
define("BUGBOARD_CUSTOM_FIELD_TYPE_RADIO",    3);
define("BUGBOARD_CUSTOM_FIELD_TYPE_TEXT",     4);

//
define("FORM_REQUIRED_MARK", '<span style="color:red;font-weight:normal">*</span>');
define("FORM_CONDITIONAL_REQUIRED_MARK", '<span style="color:red;font-weight:normal">(*)</span>');

?>