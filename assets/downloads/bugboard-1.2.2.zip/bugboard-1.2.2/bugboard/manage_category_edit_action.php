<?php
/**
 * @file
 * @brief �ץ��������Ȥ��Խ�����
 * @author typezero
 */
?>
<?php
require_once("common.php");

// �����������������å�
if (empty($_POST['acttype']) && empty($_POST['delete']) && empty($_POST['rename'])) {
    goto_error_page(lang_get('error', 'illegal_access'));
}

// ���������������¥����å�
if (empty($_SESSION['admin'])) {
    goto_error_page(lang_get('error', 'illegal_access_level'));
}

//------------------------------------------------------------


$loc = "manage_category.php";
$db  = &$db_;

if($_POST['acttype'] == 'add_category') {
    //------------------------------------------------------------
    //          add_category
    //------------------------------------------------------------
    $c_name = bugboard_mb_trim($_POST['name']);
    if ($c_name == "") {
        goto_error_page(lang_get('error', 'form_error'),
                                   lang_get('error', 'form_project_category_invalid'));
    }

    $cid = $db->nextId(BUGBOARD_CATEGORY_ID_SEQ);
    $sql = "INSERT INTO ".BUGBOARD_CATEGORY_TABLE." SET id=?,category=?";
    $db->query($sql, array($cid, $_POST['name']));
}
elseif(isset($_POST['delete'])) {
    //------------------------------------------------------------
    //          delete_category
    //------------------------------------------------------------
    $sql = "DELETE FROM ".BUGBOARD_CATEGORY_TABLE." WHERE id=?";
    $db->query($sql, array($_POST['cid']));
}
elseif(isset($_POST['rename'])) {
    //------------------------------------------------------------
    //          update_category
    //------------------------------------------------------------
    $c_name = bugboard_mb_trim($_POST['name']);
    if ($c_name == "") {
        goto_error_page(lang_get('error', 'form_error'),
                                   lang_get('error', 'form_project_category_invalid'));
    }
    
    $sql = "UPDATE ".BUGBOARD_CATEGORY_TABLE." SET category=? WHERE id=?";
    $db->query($sql, array($c_name, $_POST['cid']));
}

Header("Location:".$loc);

?>
