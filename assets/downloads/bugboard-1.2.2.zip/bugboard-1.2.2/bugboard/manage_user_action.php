<?php
/**
 * @file
 * @brief �桼������������Ⱥ�������
 * @author typezero
 */
?>
<?php
require_once("common.php");


// ���������������¥����å�
if (empty($_SESSION['admin'])) {
    goto_error_page(lang_get('error', 'illegal_access_level'));
}

// �����������������å�
if (empty($_POST)) {
    goto_error_page(lang_get('error', 'illegal_access'));
}
if (empty($_POST['act'])) {
    goto_error_page(lang_get('error', 'illegal_access'));
}

//------------------------------------------------------------
if ($_POST['act'] == "create") {

    $err = "";
    $username = bugboard_mb_trim($_POST['name']);
    $password = bugboard_mb_trim($_POST['pass']);

    if ($username == "") {
        $err .= lang_get('error', 'form_username_empty').'<br>';
    }
    if ($password == "") {
        $err .= lang_get('error', 'form_password_empty').'<br>';
    }
    elseif (mb_ereg('^[0-9a-zA-Z]+$', $password) == false) {
        $err .= lang_get('error', 'form_password_illegal').'<br>';
    }

    if ($err != "") {
        goto_error_page(lang_get('error', 'form_error'), $err);
    }


    //------------------------------------------------------------


    $db = &$db_;
    $db->autoCommit();
    $stt = "INSERT INTO ".BUGBOARD_USER_TABLE." (id,name,pass,nickname) VALUES(?,?,?,?);";
    $uid = $db->nextId(BUGBOARD_USER_ID_SEQ);

    $fields = array("id"=>$uid,
                    "name"=>$username,
                    "pass"=>MD5($password),
                    "nickname"=>$_POST['nickname']);
    $db->autoExecute(BUGBOARD_USER_TABLE, $fields, DB_AUTOQUERY_INSERT);
    $db->commit();
}
else if ($_POST['act'] == "delete") {

//    check_params(array($_POST['uid']));

    $db = &$db_;
    $db->autoCommit();
    $sql = "DELETE FROM ".BUGBOARD_USER_TABLE." WHERE id=?";
    $db->query($sql, array($_POST['uid']));
    $db->commit();
}

Header("Location: manage_user.php");

?>
