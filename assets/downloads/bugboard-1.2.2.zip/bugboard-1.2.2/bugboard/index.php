<?php
/**
 * @file
 * @brief ��ݡ��Ȱ���
 * @author typezero
 */
?>
<?php
require_once("common.php");
require_once("./templates/view.php");

print(Bugboard_HeaderTemplate());


//------------------------------------------------------------

print(Bugboard_AdminTemplate(make_admin_commands()));

//------------------------------------------------------------

$db = &$db_;

$allcheck_flag = isset($_GET['checkall']);

// check filtering parameter

$f_category = "__all";
$f_severity = 0;
$f_disp_limit = BUGBOARD_DEFAULT_DISP_LIMIT;
$f_page   = 0;
$f_mode   = "normal";
$f_status = array(BUGBOARD_BUG_STATUS_NEW,
                  BUGBOARD_BUG_STATUS_CHECKED,
                  BUGBOARD_BUG_STATUS_FEEDBACK,
                  BUGBOARD_BUG_STATUS_START,
                  BUGBOARD_BUG_STATUS_NOTREPRO,
                  BUGBOARD_BUG_STATUS_FIXED,
                  BUGBOARD_BUG_STATUS_SUSPEND,
                  BUGBOARD_BUG_STATUS_REJECTED,
                  BUGBOARD_BUG_STATUS_CLOSED);
$f_keyword = "";
$f_search_target_summary = true;
$f_search_target_body = true;
$f_orderby = $bugboard_default_sort_column;
$f_order   = $bugboard_default_sort_order;

if (isset($_GET['apply'])) {

    $f_status = array();

    if (isset($_POST['category'])) {
        $f_category = $_POST['category'];
    }
    if (isset($_POST['severity'])) {
        $f_severity = $_POST['severity'];
    }
    if (isset($_POST['disp_limit'])) {
        $f_disp_limit = intval($_POST['disp_limit']);
    }
    if (isset($_POST['status_new'])) {
        array_push($f_status, BUGBOARD_BUG_STATUS_NEW);
    }
    if (isset($_POST['status_checked'])) {
        array_push($f_status, BUGBOARD_BUG_STATUS_CHECKED);
    }
    if (isset($_POST['status_feedback'])) {
        array_push($f_status, BUGBOARD_BUG_STATUS_FEEDBACK);
    }
    if (isset($_POST['status_start'])) {
        array_push($f_status, BUGBOARD_BUG_STATUS_START);
    }
    if (isset($_POST['status_notrepro'])) {
        array_push($f_status, BUGBOARD_BUG_STATUS_NOTREPRO);
    }
    if (isset($_POST['status_fixed'])) {
        array_push($f_status, BUGBOARD_BUG_STATUS_FIXED);
    }
    if (isset($_POST['status_suspend'])) {
        array_push($f_status, BUGBOARD_BUG_STATUS_SUSPEND);
    }
    if (isset($_POST['status_rejected'])) {
        array_push($f_status, BUGBOARD_BUG_STATUS_REJECTED);
    }
    if (isset($_POST['status_closed'])) {
        array_push($f_status, BUGBOARD_BUG_STATUS_CLOSED);
    }
    if (isset($_POST['search_keyword'])) {
        $f_keyword = $_POST['search_keyword'];
    }
    if (empty($_POST['search_target_summary'])) {
        $f_search_target_summary = false;
    }
    if (empty($_POST['search_target_body'])) {
        $f_search_target_body = false;
    }
}
elseif (isset($_GET['refresh'])) {

    $f_category              = $_SESSION['filter']['category'];
    $f_severity              = $_SESSION['filter']['severity'];
    $f_disp_limit            = $_SESSION['filter']['disp_limit'];
    $f_status                = $_SESSION['filter']['status'];
    $f_keyword               = $_SESSION['filter']['search_keyword'];
    $f_search_target_summary = $_SESSION['filter']['search_target_summary'];
    $f_search_target_body    = $_SESSION['filter']['search_target_body'];
}
else {
    unset($_SESSION['filter']);
    unset($_SESSION['sort']);
}

if (isset($_SESSION['sort'])) {
    $f_orderby = $_SESSION['sort']['orderby'];
    $f_order   = $_SESSION['sort']['order'];
}

if (isset($_GET['orderby'])) {
    $f_orderby = $_GET['orderby'];
}

if (isset($_GET['order'])) {
    $f_order = $_GET['order'];
}

if (isset($_GET['page'])) {
    $f_page = intval($_GET['page']);
}

if (isset($_GET['mode'])) {
    $f_mode = $_GET['mode'];
}

// filter setting save

$_SESSION['filter']['category']              = $f_category;
$_SESSION['filter']['severity']              = $f_severity;
$_SESSION['filter']['status']                = $f_status;
$_SESSION['filter']['disp_limit']            = $f_disp_limit;
$_SESSION['filter']['search_keyword']        = $f_keyword;
$_SESSION['filter']['search_target_summary'] = $f_search_target_summary;
$_SESSION['filter']['search_target_body']    = $f_search_target_body;

// sort setting save

$_SESSION['sort']['orderby'] = $f_orderby;
$_SESSION['sort']['order']   = $f_order;

// ---------- fliter ----------

$tbl = new Gull_Table_Html(array("class"=>"listbox"));

$tbl->beginRow();
$tbl->insertHeadCenter(lang_get('bug_category_name'), array("width"=>"100"));
$tbl->insertHeadCenter(lang_get('bug_severity_name'), array("width"=>"100"));
$tbl->insertHeadCenter(lang_get('bug_disp_limit_name'), array("width"=>"100"));
$tbl->insertHeadCenter('', array("width"=>"100%"));
$tbl->endRow();

$tbl->beginRow();


$categories = $db->getCol("SELECT category FROM ".BUGBOARD_CATEGORY_TABLE, 0);
$tmp = array('__all'=>'[����]');
foreach($categories as $value) {
    $tmp[$value] = htmlspecialchars($value);
}
$tbl->insertDataCenter(make_select_tag($tmp, $f_category, array("name"=>"category",
                                                                "style"=>"width:100px")));

$severities = lang_get('bug_severity');
array_unshift($severities, '[����]');
$tbl->insertDataCenter(make_select_tag($severities, $f_severity, array("name"=>"severity",
                                                                       "style"=>"width:100px")));

$tbl->insertData(make_input_tag("text", "disp_limit", $f_disp_limit), array("style"=>"width:100px"));

$tbl->insertData('', array("style"=>"width:100%"));
$tbl->endRow();
$tbl->nextTile();
$tbl->BeginRow();
$tbl->insertHeadCenter(lang_get('bug_status_name'));
$space = "&nbsp;&nbsp;&nbsp;";
$html  = make_input_tag("checkbox", "status_new", "new", in_array(BUGBOARD_BUG_STATUS_NEW, $f_status));
$html .= "&nbsp;".lang_get('bug_status', BUGBOARD_BUG_STATUS_NEW)."\n";
$html .= $space.make_input_tag("checkbox", "status_checked", "checked", in_array(BUGBOARD_BUG_STATUS_CHECKED, $f_status));
$html .= "&nbsp;".lang_get('bug_status', BUGBOARD_BUG_STATUS_CHECKED)."\n";
$html .= $space.make_input_tag("checkbox", "status_feedback", "feedback", in_array(BUGBOARD_BUG_STATUS_FEEDBACK, $f_status));
$html .= "&nbsp;".lang_get('bug_status', BUGBOARD_BUG_STATUS_FEEDBACK)."\n";
$html .= $space.make_input_tag("checkbox", "status_start", "start", in_array(BUGBOARD_BUG_STATUS_START, $f_status));
$html .= "&nbsp;".lang_get('bug_status', BUGBOARD_BUG_STATUS_START)."\n";
$html .= $space.make_input_tag("checkbox", "status_notrepro", "notrepro", in_array(BUGBOARD_BUG_STATUS_NOTREPRO, $f_status));
$html .= "&nbsp;".lang_get('bug_status', BUGBOARD_BUG_STATUS_NOTREPRO)."\n";
$html .= $space.make_input_tag("checkbox", "status_fixed", "fixed", in_array(BUGBOARD_BUG_STATUS_FIXED, $f_status));
$html .= "&nbsp;".lang_get('bug_status', BUGBOARD_BUG_STATUS_FIXED)."\n";
$html .= $space.make_input_tag("checkbox", "status_suspend", "suspend", in_array(BUGBOARD_BUG_STATUS_SUSPEND, $f_status));
$html .= "&nbsp;".lang_get('bug_status', BUGBOARD_BUG_STATUS_SUSPEND)."\n";
$html .= $space.make_input_tag("checkbox", "status_rejected", "rejected",in_array(BUGBOARD_BUG_STATUS_REJECTED, $f_status));
$html .= "&nbsp;".lang_get('bug_status', BUGBOARD_BUG_STATUS_REJECTED)."\n";
$html .= $space.make_input_tag("checkbox", "status_closed", "closed", in_array(BUGBOARD_BUG_STATUS_CLOSED, $f_status));
$html .= "&nbsp;".lang_get('bug_status', BUGBOARD_BUG_STATUS_CLOSED)."\n";

$tbl->insertData($html, array("colspan"=>3));
$tbl->endRow();
$tbl->nextTile();


$tbl->beginRow();
$tbl->insertHeadCenter("����");

$html = make_tag("input", array("type"=>"text", "name"=>"search_keyword", "value"=>$f_keyword, "size"=>80));
$html.= "&nbsp;<br />";
$html.= "�����оݡ�";

$html .= make_input_tag("checkbox", "search_target_summary", "summary", $f_search_target_summary);
$html .= "&nbsp;".lang_get('bug_summary_name')."&nbsp;";
$html .= make_input_tag("checkbox", "search_target_body", "body", $f_search_target_body);
$html .= "&nbsp;".lang_get('bug_body_name');
$tbl->insertData($html, array("colspan"=>3));
$tbl->endRow();
$tbl->nextTile();


$tbl->beginRow();
$tbl->insertDataCenter(make_tag("input",array("type"=>"submit","value"=>"��Ŭ�ѡ�")), array("colspan"=>6));
$tbl->endRow();
$tbl->nextTile();

$tbl->endTable();

print(Bugboard_ViewTemplateFilter($_GET['mode'], $tbl->to_html()));


// ---------- color_sample + report count ----------

$cnt_total    = $db->getOne("SELECT COUNT(*) FROM ".BUGBOARD_BUG_TABLE."");
$cnt_new      = $db->getOne("SELECT COUNT(*) FROM ".BUGBOARD_BUG_TABLE." WHERE status=?", array(BUGBOARD_BUG_STATUS_NEW));
$cnt_checked  = $db->getOne("SELECT COUNT(*) FROM ".BUGBOARD_BUG_TABLE." WHERE status=?", array(BUGBOARD_BUG_STATUS_CHECKED));
$cnt_feedback = $db->getOne("SELECT COUNT(*) FROM ".BUGBOARD_BUG_TABLE." WHERE status=?", array(BUGBOARD_BUG_STATUS_FEEDBACK));
$cnt_start    = $db->getOne("SELECT COUNT(*) FROM ".BUGBOARD_BUG_TABLE." WHERE status=?", array(BUGBOARD_BUG_STATUS_START));
$cnt_notrepro = $db->getOne("SELECT COUNT(*) FROM ".BUGBOARD_BUG_TABLE." WHERE status=?", array(BUGBOARD_BUG_STATUS_NOTREPRO));
$cnt_fixed    = $db->getOne("SELECT COUNT(*) FROM ".BUGBOARD_BUG_TABLE." WHERE status=?", array(BUGBOARD_BUG_STATUS_FIXED));
$cnt_suspend  = $db->getOne("SELECT COUNT(*) FROM ".BUGBOARD_BUG_TABLE." WHERE status=?", array(BUGBOARD_BUG_STATUS_SUSPEND));
$cnt_rejected = $db->getOne("SELECT COUNT(*) FROM ".BUGBOARD_BUG_TABLE." WHERE status=?", array(BUGBOARD_BUG_STATUS_REJECTED));
$cnt_closed   = $db->getOne("SELECT COUNT(*) FROM ".BUGBOARD_BUG_TABLE." WHERE status=?", array(BUGBOARD_BUG_STATUS_CLOSED));

$tbl = new Gull_Table_Html(array("class"=>"color_sample"));
$tbl->beginRow();
$tbl->insertData("����", array("class"=>"grid_total"));
$tbl->insertData(lang_get('bug_status', BUGBOARD_BUG_STATUS_NEW),      array("class"=>getBugStatusClass(BUGBOARD_BUG_STATUS_NEW)));
$tbl->insertData(lang_get('bug_status', BUGBOARD_BUG_STATUS_CHECKED),  array("class"=>getBugStatusClass(BUGBOARD_BUG_STATUS_CHECKED)));
$tbl->insertData(lang_get('bug_status', BUGBOARD_BUG_STATUS_FEEDBACK), array("class"=>getBugStatusClass(BUGBOARD_BUG_STATUS_FEEDBACK)));
$tbl->insertData(lang_get('bug_status', BUGBOARD_BUG_STATUS_START),    array("class"=>getBugStatusClass(BUGBOARD_BUG_STATUS_START)));
$tbl->insertData(lang_get('bug_status', BUGBOARD_BUG_STATUS_NOTREPRO), array("class"=>getBugStatusClass(BUGBOARD_BUG_STATUS_NOTREPRO)));
$tbl->insertData(lang_get('bug_status', BUGBOARD_BUG_STATUS_FIXED),    array("class"=>getBugStatusClass(BUGBOARD_BUG_STATUS_FIXED)));
$tbl->insertData(lang_get('bug_status', BUGBOARD_BUG_STATUS_SUSPEND),  array("class"=>getBugStatusClass(BUGBOARD_BUG_STATUS_SUSPEND)));
$tbl->insertData(lang_get('bug_status', BUGBOARD_BUG_STATUS_REJECTED), array("class"=>getBugStatusClass(BUGBOARD_BUG_STATUS_REJECTED)));
$tbl->insertData(lang_get('bug_status', BUGBOARD_BUG_STATUS_CLOSED),   array("class"=>getBugStatusClass(BUGBOARD_BUG_STATUS_CLOSED)));
$tbl->endRow();
$tbl->beginRow();
$tbl->insertData($cnt_total);
$tbl->insertData($cnt_new);
$tbl->insertData($cnt_checked);
$tbl->insertData($cnt_feedback);
$tbl->insertData($cnt_start);
$tbl->insertData($cnt_notrepro);
$tbl->insertData($cnt_fixed);
$tbl->insertData($cnt_suspend);
$tbl->insertData($cnt_rejected);
$tbl->insertData($cnt_closed);
$tbl->endRow();
$tbl->endTable();

$html = "<div class=\"sub_title\">��ݡ��ȤΥ��ơ���������</div>".$tbl->to_html();

print(Bugboard_ViewTemplateStatus($html));

if ($cnt_total>0) {

    $status_new_rate      = ceil(($cnt_new*100)/$cnt_total);
    $status_checked_rate  = ceil(($cnt_checked*100)/$cnt_total);
    $status_feedback_rate = ceil(($cnt_feedback*100)/$cnt_total);
    $status_start_rate    = ceil(($cnt_start*100)/$cnt_total);
    $status_notrepro_rate = ceil(($cnt_notrepro*100)/$cnt_total);
    $status_fixed_rate    = ceil(($cnt_fixed*100)/$cnt_total);
    $status_suspend_rate  = ceil(($cnt_suspend*100)/$cnt_total);
    $status_rejected_rate = ceil(($cnt_rejected*100)/$cnt_total);
    $status_closed_rate   = ceil(($cnt_closed*100)/$cnt_total);

    $status_rate_cnt = 0;
    if ($status_new_rate>0)       { $status_rate_cnt++; }
    if ($status_checked_rate>0)   { $status_rate_cnt++; }
    if ($status_feedback_rate>0)  { $status_rate_cnt++; }
    if ($status_start_rate>0)     { $status_rate_cnt++; }
    if ($status_notreprot_rate>0) { $status_rate_cnt++; }
    if ($status_fixed_rate>0)     { $status_rate_cnt++; }
    if ($status_suspend_rate>0)   { $status_rate_cnt++; }
    if ($status_rejected_rate>0)  { $status_rate_cnt++; }
    if ($status_closed_rate>0)    { $status_rate_cnt++; }

    $tbl = new Gull_Table_Html(array("class"=>"status_rate"));
    $tbl->beginRow();

    if ($status_new_rate>0) {
        $tbl->insertData("$status_new_rate%",
                         array("class"=>getBugStatusClass(BUGBOARD_BUG_STATUS_NEW),
                               "style"=>"width:$status_new_rate%"));
    }
    if ($status_checked_rate>0) {
        $tbl->insertData("$status_checked_rate%",
                         array("class"=>getBugStatusClass(BUGBOARD_BUG_STATUS_CHECKED),
                               "style"=>"width:$status_checked_rate%"));
    }
    if ($status_feedback_rate>0) {
        $tbl->insertData("$status_feedback_rate%",
                         array("class"=>getBugStatusClass(BUGBOARD_BUG_STATUS_FEEDBACK),
                               "style"=>"width:$status_feedback_rate%"));
    }
    if ($status_start_rate>0) {
        $tbl->insertData("$status_start_rate%",
                         array("class"=>getBugStatusClass(BUGBOARD_BUG_STATUS_START),
                               "style"=>"width:$status_start_rate%"));
    }
    if ($status_notrepro_rate>0) {
        $tbl->insertData("$status_notrepro_rate%",
                         array("class"=>getBugStatusClass(BUGBOARD_BUG_STATUS_NOTREPRO),
                               "style"=>"width:$status_notrepro_rate%"));
    }
    if ($status_fixed_rate>0) {
        $tbl->insertData("$status_fixed_rate%",
                         array("class"=>getBugStatusClass(BUGBOARD_BUG_STATUS_FIXED),
                               "style"=>"width:$status_fixed_rate%"));
    }
    if ($status_suspend_rate>0) {
        $tbl->insertData("$status_suspend_rate%",
                         array("class"=>getBugStatusClass(BUGBOARD_BUG_STATUS_SUSPEND),
                               "style"=>"width:$status_suspend_rate%"));
    }
    if ($status_rejected_rate>0) {
        $tbl->insertData("$status_rejected_rate%",
                         array("class"=>getBugStatusClass(BUGBOARD_BUG_STATUS_REJECTED),
                               "style"=>"width:$status_rejected_rate%"));
    }
    if ($status_closed_rate>0) {
        $tbl->insertData("$status_closed_rate%",
                         array("class"=>getBugStatusClass(BUGBOARD_BUG_STATUS_CLOSED),
                               "style"=>"width:$status_closed_rate%"));
    }
    $tbl->endRow();
    $tbl->endTable();

    $html = "<div class=\"sub_title\">��ݡ��ȤΥ��ơ��������</div>".$tbl->to_html();

    print(Bugboard_ViewTemplateStatus($html));
}


// ---------- list ----------


// �ե��륿�����̤�����ݡ��Ȱ����μ���

$where = "";
$conditions = array();

if ($f_category != '__all') {
    array_push($conditions, " AND category=".$db->quoteSmart($f_category));
//    $where .= " AND category=".$db->quoteSmart($f_category);
}
if ($f_severity != 0) {
    array_push($conditions, " AND severity=".$db->quoteSmart($f_severity));
//    $where .= " AND severity=".$db->quoteSmart($f_severity);
}
if (count($f_status)>0) {
    array_push($conditions, " AND status IN (".implode(",", $f_status).")");
//    $where .= " AND status IN (".implode(",", $f_status).")";
}

if ($f_keyword != "" && ($f_search_target_summary || $f_search_target_body)) {

    // MySQL 4.* �ϥ��֥����꡼�򥵥ݡ��Ȥ��Ƥ��ʤ��ΤǻȤ�ʤ��褦�ˤ���

    $sql  = "SELECT ".BUGBOARD_BUG_TABLE.".id FROM ".BUGBOARD_BUG_TABLE;
    $sql .= " LEFT JOIN ".BUGBOARD_BUG_TEXT_TABLE." ON ".BUGBOARD_BUG_TABLE.".body_id=".BUGBOARD_BUG_TEXT_TABLE.".id";
    
    $where = " WHERE ";

    if ($f_search_target_summary) {
        $where .= BUGBOARD_BUG_TABLE.".summary LIKE '%".$f_keyword."%' OR ";
    }
    if ($f_search_target_body) {
        $where .= BUGBOARD_BUG_TEXT_TABLE.".body LIKE '%".$f_keyword."%'";
    }
    else {
        $where .= "0<>0";
    }

    $rs = $db->getCol($sql.$where);
    if (count($rs)>0) {
        array_push($conditions, " AND id IN (".implode(",", $rs).")");
    }
    else {
        array_push($conditions, " AND 0<>0");
    }
}

if (count($conditions)>0) {
    $where = " WHERE 1<>0";// 1<>0 is dummy
    foreach ($conditions as $cond) {
        $where .= $cond;
    }
}

if (isset($f_orderby)) {
    
    if ($f_order == "ascend")
        $sql_order = "ASC";
    else
        $sql_order = "DESC";

    $where .= " ORDER BY ".$f_orderby." ".$sql_order;
}

$sql = "SELECT * FROM ".BUGBOARD_BUG_TABLE;

log_debug($sql.$where);

$report_num = $db->getOne("SELECT COUNT(*) FROM ".BUGBOARD_BUG_TABLE.$where);

if ($f_disp_limit > 0) {
    $rs = $db->limitQuery($sql.$where, $f_page*$f_disp_limit, $f_disp_limit);
} else {
    $rs = $db->query($sql.$where);
}

$report_disp_num = $rs->numRows();

if ($report_disp_num == 0) {
    if (isset($_GET['mode']) && $_GET['mode'] == "group") {
        $listmode = "normal";
        $listmode_name = "�̾�ɽ��";
        $curmode       = "group";
    } else {
        $listmode = "group";
        $listmode_name = "���롼��ɽ��";
        $curmode  = "normal";
    }

    print(Bugboard_ViewTemplateMenu($listmode, $listmode_name, $curmode));
    print(Bugboard_ViewTemplateList('<div class="mgn32">���פ����ݡ��Ȥ�¸�ߤ��ޤ���</div>'));
    print(Bugboard_FooterTemplate());
    exit();
}

// assign to template


//$o_smarty->assign("report_count", $rs->numRows());

function item_link($name, $orderby) {
    global $f_orderby;
    global $f_order;
    global $pid;
    $order;
    $mark;
    
    $mode = "&amp;refresh";
    if (isset($_GET['mode']) && $_GET['mode'] == "group") {
        $mode .= "&amp;mode=group";
    }
    
    if ($f_orderby==$orderby) {
        if ($f_order == "descend") {
            $order = "ascend";
            $mark = "��";
        }
        else {
            $order = "descend";
            $mark = "��";
        }

        $tmp  = '<a href="'.$_SERVER['PHP_SELF'].'?pid='.$pid.$mode.'&amp;orderby='.$orderby.'&amp;order='.$order.'">'.$name.'</a>';
        $tmp .= "&nbsp;".$mark;
    }
    else {
        $tmp = '<a href="'.$_SERVER['PHP_SELF'].'?pid='.$pid.$mode.'&amp;refresh&amp;orderby='.$orderby.'&amp;order=descend">'.$name.'</a>';
    }

    return $tmp;
}

function make_report_list_item($tbl, $row)
{
    $href     = "view_report.php?bid=".$row['id'];
    $tgt      = "_blank";
    
    $tbl->beginRow(array("class"=>getBugStatusClass($row['status'])));

    global $bugboard_disp_columns;

    foreach ($bugboard_disp_columns as $column) {

        switch ($column) {
        case "id":

            // id
            $html = make_tag_closed("a", array("href"=>$href,
                                               "target"=>$tgt),
                                    id_to_str($row['id']));
            $tbl->insertDataCenter($html, array("class"=>"small", "style"=>"width:100px"));
            break;

        case "summary":
            // summary
            $tbl->insertData(make_tag_closed("a",
                                             array("href"=>$href,
                                                   "target"=>$tgt,
                                                   "class"=>"summary"),
                                             htmlspecialchars($row['summary'])),
                             array("style"=>"width:50%"));
            break;

        case "category":
        case "reporter":
        case "last_updater":
            $tbl->insertData(htmlspecialchars($row[$column]), array("nowrap"));
            break;

        case "severity":
            $tbl->insertData(lang_get('bug_severity', $row['severity']), array("nowrap"));
            break;

        case "status":
            $tbl->insertData(lang_get('bug_status', $row['status']), array("nowrap"));
            break;

        case "vote_count":
            $tbl->insertDataCenter(htmlspecialchars($row[$column]), array("nowrap"));
            break;

        case "last_updated":
        case "date_submitted":
            $tbl->insertDataCenter(date_as_text($row[$column]), array("nowrap"));
            break;

        case "comment_count":
            global $db;
            $tbl->insertDataCenter($db->getOne("SELECT COUNT(*) FROM ".BUGBOARD_BUG_NOTE_TABLE." WHERE bid=?", array($row['id'])), array("nowrap"));
            break;
        }
    }

    $tbl->endRow();
}


if (empty($_GET['mode']) || $_GET['mode'] == 'normal') {

    $tbl = new Gull_Table_Html(array("class"=>"selectbox", "id"=>"selectbox"));
    $tbl->beginRow();

    foreach ($bugboard_disp_columns as $column) {

        switch ($column) {
        case "category":
        case "severity":
        case "status":
        case "reporter":
        case "date_submitted":
        case "last_updated":
        case "last_updater":
        case "vote_count":
        case "comment_count":
            $tbl->insertHeadCenter(item_link(lang_get($column), $column), array("nowrap"));
            break;
        default:
            $tbl->insertHeadCenter(item_link(lang_get($column), $column));
            break;
        }

    }
    $tbl->endRow();
    $tbl->setInterlaceMode(true);

    while ($row = $rs->fetchRow(DB_FETCHMODE_ASSOC)) {
        make_report_list_item($tbl, $row);
    }
    $tbl->endTable();

    $content = "";
    if ($report_disp_num>0) {
        $content = $tbl->to_html();
    }
    else {
        $tbl->to_html();// �����ǥХåե���󥰤��Ƥ��뤿��
    }

    print(Bugboard_ViewTemplateMenu("group", "���롼��ɽ��", "normal"));
    print(Bugboard_ViewTemplateList($content));
}
else {

    $tbl = new Gull_Table_Html(array("class"=>"selectbox", "id"=>"selectbox"));
    $tbl->beginRow();

    foreach ($bugboard_disp_columns as $column) {

        switch ($column) {
        case "category":
        case "severity":
        case "status":
        case "reporter":
        case "date_submitted":
        case "last_updated":
        case "last_updater":
        case "vote_count":
            $tbl->insertHeadCenter(item_link(lang_get($column), $column), array("nowrap"));
            break;
        default:
            $tbl->insertHeadCenter(item_link(lang_get($column), $column));
            break;
        }

    }
    $tbl->endRow();

    //------------------------------------------------------------

    $status_list = array(BUGBOARD_BUG_STATUS_NEW,
                         BUGBOARD_BUG_STATUS_CHECKED,
                         BUGBOARD_BUG_STATUS_FEEDBACK,
                         BUGBOARD_BUG_STATUS_START,
                         BUGBOARD_BUG_STATUS_NOTREPRO,
                         BUGBOARD_BUG_STATUS_FIXED,
                         BUGBOARD_BUG_STATUS_SUSPEND,
                         BUGBOARD_BUG_STATUS_REJECTED,
                         BUGBOARD_BUG_STATUS_CLOSED);

    $list_new      = array();
    $list_start    = array();
    $list_notrepro = array();
    $list_checked  = array();
    $list_feedback = array();
    $list_fixed    = array();
    $list_suspend  = array();
    $list_rejected = array();
    $list_closed   = array();

    while ($row = $rs->fetchRow(DB_FETCHMODE_ASSOC)) {
        switch ($row['status']) {
        case BUGBOARD_BUG_STATUS_NEW:      array_push($list_new,      $row);break;
        case BUGBOARD_BUG_STATUS_CHECKED:  array_push($list_checked,  $row);break;
        case BUGBOARD_BUG_STATUS_FEEDBACK: array_push($list_feedback, $row);break;
        case BUGBOARD_BUG_STATUS_START:    array_push($list_start,    $row);break;
        case BUGBOARD_BUG_STATUS_NOTREPRO: array_push($list_notrepro, $row);break;
        case BUGBOARD_BUG_STATUS_FIXED:    array_push($list_fixed,    $row);break;
        case BUGBOARD_BUG_STATUS_SUSPEND:  array_push($list_suspend,  $row);break;
        case BUGBOARD_BUG_STATUS_REJECTED: array_push($list_rejected, $row);break;
        case BUGBOARD_BUG_STATUS_CLOSED:   array_push($list_closed,   $row);break;
        }
    }

    $html = "";

    function make_list($smarty, $list, $tbl, $assign) {
        if (count($list)>0) {
            $tbl->insertBlankRow();
            foreach ($list as $report) {
                make_report_list_item($tbl, $report);
            }
        }
    }

    make_list($o_smarty, $list_new,      $tbl, "list_new");
    make_list($o_smarty, $list_checked,  $tbl, "list_checked");
    make_list($o_smarty, $list_feedback, $tbl, "list_feedback");
    make_list($o_smarty, $list_start,    $tbl, "list_start");
    make_list($o_smarty, $list_notrepro, $tbl, "list_notrepro");
    make_list($o_smarty, $list_fixed,    $tbl, "list_fixed");
    make_list($o_smarty, $list_suspend,  $tbl, "list_suspend");
    make_list($o_smarty, $list_rejected, $tbl, "list_rejected");
    make_list($o_smarty, $list_closed,   $tbl, "list_closed");

    $tbl->endTable();

    $content = $tbl->to_html();
    print(Bugboard_ViewTemplateMenu("normal", "�̾�ɽ��", "group"));
    print(Bugboard_ViewTemplateList($content));
}

// pagination
if ($f_disp_limit>0) {
    $html = "";

    $page_cnt = 0;
    $cur_page = $f_page-1;
    while ($cur_page>=0) {
        $html = '<a href="index.php?refresh&amp;mode='.$f_mode."&amp;page=$cur_page\">".strval($cur_page+1)."</a>".$html;
        $cur_page--;
        $page_cnt++;
        if ($page_cnt >= BUGBOARD_PAGINATION_LIMIT) {
            break;
        }
    }
    if ($cur_page < $f_page-1) {
        $html = '<a href="index.php?refresh&amp;mode='.$f_mode.'&amp;page='.strval($f_page-1).'">����</a>'.$html;
    }
    
    $html .= '<span class="current">'.strval($f_page+1).'</span>';

    $page_cnt = 0;
    $cur_page = $f_page+1;
    while ($cur_page * $f_disp_limit < $report_num) {
        $html .= '<a href="index.php?refresh&amp;mode='.$f_mode."&amp;page=$cur_page\">".strval($cur_page+1)."</a>";
        $cur_page++;

        $page_cnt++;
        if ($page_cnt >= BUGBOARD_PAGINATION_LIMIT) {
            break;
        }
    }
    if ($cur_page > $f_page+1) {
        $html .= '<a href="index.php?refresh&amp;mode='.$f_mode.'&amp;page='.strval($f_page+1).'">����</a>';
    }

    $html = '<div class="pagination">'.$html.'</div>';
    print($html);
}

print(Bugboard_FooterTemplate());

?>
