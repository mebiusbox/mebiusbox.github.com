<?php
/**
 * @file gen_rss.php
 * @brief RSS����
 * @author typezero
 */
?>
<?php
require_once("common.php");

//------------------------------------------------------------
// generate rss feed
//------------------------------------------------------------
function gen_rss(&$db) {

    if (BUGBOARD_GENERATE_RSS) {
        $writer = new RssWriter(BUGBOARD_INTERNAL_ENCODING);

        $baseurl = 'http://'.$_SERVER['SERVER_NAME'].ereg_replace("/[a-zA-Z0-9_]+\.php","",$_SERVER['PHP_SELF']);
        $writer->WriteChannel($baseurl."/rss/index.rdf",
                              PROJECT_NAME." - Bugboard",
                              $baseurl."/",
                              PROJECT_NAME." - Bugboard feed");

        $ret = $db->limitQuery("SELECT * FROM ".BUGBOARD_BUG_TABLE." ORDER BY date_submitted DESC", 0, BUGBOARD_RSS_ITEM_MAX);
        while ($item = $ret->fetchRow(DB_FETCHMODE_ASSOC)) {

            $body = $db->getOne("SELECT body FROM ".BUGBOARD_BUG_TEXT_TABLE." WHERE id=?", array($item['body_id']));
            $body = htmlspecialchars($body);
            $body = mb_convert_encoding($body, BUGBOARD_INTERNAL_ENCODING, BUGBOARD_DB_ENCODING);

            // $date = YYYY-MM-DD HH:MM
            $date = date_as_text($item['date_submitted']);
            // $dc_date = YYYY-MM-DDTHH:MM:SS+09:00
            $dc_date  = substr($date,0,10);//YYYY-MM-DD
            $dc_date .= "T";
            $dc_date .= substr($date,11,5);//HH:MM
            $dc_date .= ":00+09:00";

            $writer->AddItem(id_to_str($item['id']),
                             mb_convert_encoding($item['summary'], BUGBOARD_INTERNAL_ENCODING, BUGBOARD_DB_ENCODING),
                             $baseurl."/view_report.php?bid=".$item['id'],
                             mb_strimwidth($body,0,512,"..", BUGBOARD_INTERNAL_ENCODING),
                             array("dc:date" => $dc_date));
        }

        log_debug($baseurl);
        log_debug($writer->Gen());

        write_file("./rss/index.rdf", $writer->Gen());
    }
}

//------------------------------------------------------------
// generate comments rss feed
//------------------------------------------------------------
function gen_comments_rss(&$db) {
    
    if (BUGBOARD_GENERATE_COMMENTS_RSS) {

        $writer = new RssWriter(BUGBOARD_INTERNAL_ENCODING);

        $baseurl = 'http://'.$_SERVER['SERVER_NAME'].ereg_replace("/[a-zA-Z0-9_]+\.php$","",$_SERVER['PHP_SELF']);
        $writer->WriteChannel($baseurl."/rss/comments.rdf",
                              PROJECT_NAME." - Bugboard comments",
                              $baseurl."/",
                              PROJECT_NAME." - Bugboard comments feed");

        $ret = $db->limitQuery("SELECT * FROM ".BUGBOARD_BUG_NOTE_TABLE." ORDER BY date_submitted DESC", 0, BUGBOARD_COMMENTS_RSS_ITEM_MAX);
        while ($item = $ret->fetchRow(DB_FETCHMODE_ASSOC)) {

            $body = $db->getOne("SELECT body FROM ".BUGBOARD_BUG_NOTE_TEXT_TABLE." WHERE id=?", array($item['body_id']));
            $body = htmlspecialchars($body);
            $body = mb_convert_encoding($body, BUGBOARD_INTERNAL_ENCODING, BUGBOARD_DB_ENCODING);

            $summary = $db->getOne('SELECT summary FROM '.BUGBOARD_BUG_TABLE." WHERE id=?", array($item['bid']));

            // $date = YYYY-MM-DD HH:MM
            $date = date_as_text($item['date_submitted']);
            // $dc_date = YYYY-MM-DDTHH:MM:SS+09:00
            $dc_date  = substr($date,0,10);//YYYY-MM-DD
            $dc_date .= "T";
            $dc_date .= substr($date,11,5);//HH:MM
            $dc_date .= ":00+09:00";

            $name  = htmlspecialchars(bugboard_mb_strip_nl($item['name']));
            $title = "Comment on ".mb_convert_encoding($summary, BUGBOARD_INTERNAL_ENCODING, BUGBOARD_DB_ENCODING)." by ".$name;

            $writer->AddItem(id_to_str($item['id']),
                             $title,
                             $baseurl."/view_report.php?bid=".$item['bid']."#comment-".$item['id'],
                             mb_strimwidth($body,0,512,"..", BUGBOARD_INTERNAL_ENCODING),
                             array("dc:date" => $dc_date));
        }

        log_debug($baseurl);
        log_debug($writer->Gen());

        write_file("./rss/comments.rdf", $writer->Gen());
    }
}
?>