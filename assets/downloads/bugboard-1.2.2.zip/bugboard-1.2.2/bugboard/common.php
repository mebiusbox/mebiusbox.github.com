<?php
/**
 * @file
 * @brief  ���̣��У�
 * @author typezero
 */
?>
<?php

session_cache_expire(600);
session_start();

require_once(dirname(__FILE__).DIRECTORY_SEPARATOR."alias-dir.php");
require_once("DB.php");
require_once($g_core_dir."const_inc.php");
require_once($g_base_dir."config.php");
require_once($g_base_dir."alias-db.php");
require_once($g_core_dir."logging_api.php");
require_once($g_core_dir."html_api.php");
require_once($g_core_dir."table_api.php");
require_once($g_core_dir."sql_api.php");
require_once($g_core_dir."file_api.php");
require_once($g_core_dir."rss_api.php");
require_once($g_core_dir."captcha_api.php");
require_once("./templates/common.php");
require_once("./js.php");

//------------------------------------------------------------

function goto_error_page($err, $comment=null) {

    print(Bugboard_HeaderTemplate());
    print(Bugboard_ErrorboxTemplate($err,$comment));
    print(Bugboard_FooterTemplate());
    exit(0);
}

function goto_info_page($caption="", $summary="", $comment=null) {

    print(Bugboard_HeaderTemplate());
    print(Bugboard_InfoboxTemplate($caption,$summary,$comment));
    print(Bugboard_FooterTemplate());
    exit(0);
}

//------------------------------------------------------------

function check_params($params) {
    foreach ($params as $value) {
        if (empty($value)) {
            goto_error_page(lang_get('error', 'illegal_param'));
            return false;
        }
    }

    return true;
}

function check_assoc_params($params, $assoc_array) {
    global $o_smarty;
    foreach ($assoc_array as $assoc) {
        if (empty($params[$assoc])) {
            goto_error_page(lang_get('error', 'illegal_param'));
            return false;
        }
    }

    return true;
}

//------------------------------------------------------------
$db_ = null;

/**
 */
function errHandle($err) {

    log_error($err->getCode().":".$err->getMessage());

    global $db_;
    if (isset($db_)) {
        $db_->rollback();
    }
    goto_error_page('��̿Ū���顼��ȯ�����ޤ���', '���β��̤��Ф�������Ԥ���𤷤Ƥ������������ΤȤ���ȯ�����֤��⤷�Ƥ���������');
}

PEAR::setErrorHandling(PEAR_ERROR_CALLBACK, "errHandle");

//------------------------------------------------------------

//session_cache_expire(600);
//session_start();

$dsn = BUGBOARD_DB_SQLTYPE."://".BUGBOARD_DB_USERNAME.":".BUGBOARD_DB_PASS."@".BUGBOARD_DB_HOST."/".BUGBOARD_DB_NAME;
$db_ = DB::connect($dsn,
                         array("autofree"=>TRUE,
                               "portability"=>DB_PORTABILITY_ALL));
if (DB::isError($db_)) {
    $db_ = NULL;
}
if (BUGBOARD_DB_SQLTYPE == "mysqli") {
    $db_->query("SET NAMES ujis");
}


// ��������
// �桼�������󤬥��å�������¸����Ƥ���Ϥ�

require_once($g_lang_dir."lang_jpn.php");
require_once($g_core_dir."lang_api.php");
require_once("misc.php");

?>
