<?php
header("Expires: Thu, 01 Dec 1994 16:00:00 GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
if (isset($_GET['feed'])) {
    if ($_GET['feed'] == "rss") {
        readfile("index.rdf");
    }
    elseif ($_GET['feed'] == 'comments-rss') {
        readfile("comments.rdf");
    }
} else {
    readfile("index.rdf");
}
?>