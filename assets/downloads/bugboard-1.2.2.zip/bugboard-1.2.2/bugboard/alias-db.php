<?php
/**
 * @file  
 * @brief �ǡ����١����ơ��֥�̾���
 * @author typezero
 */
?>
<?php
define("BUGBOARD_USER_TABLE",           BUGBOARD_DB_TABLE_PREFIX."user_table");
define("BUGBOARD_CATEGORY_TABLE",       BUGBOARD_DB_TABLE_PREFIX."category_table");
define("BUGBOARD_BUG_TABLE",            BUGBOARD_DB_TABLE_PREFIX."bug_table");
define("BUGBOARD_BUG_TEXT_TABLE",       BUGBOARD_DB_TABLE_PREFIX."bug_text_table");
define("BUGBOARD_BUG_FILE_TABLE",       BUGBOARD_DB_TABLE_PREFIX."bug_file_table");
define("BUGBOARD_BUG_NOTE_TABLE",       BUGBOARD_DB_TABLE_PREFIX."bug_note_table");
define("BUGBOARD_BUG_NOTE_TEXT_TABLE",  BUGBOARD_DB_TABLE_PREFIX."bug_note_text_table");
define("BUGBOARD_CUSTOM_FIELD_TABLE",   BUGBOARD_DB_TABLE_PREFIX."custom_field_table");
define("BUGBOARD_CUSTOM_FIELD_STRING_TABLE", BUGBOARD_DB_TABLE_PREFIX."custom_field_string_table");
define("BUGBOARD_USER_ID_SEQ",          BUGBOARD_DB_TABLE_PREFIX."user_id");
define("BUGBOARD_BUG_ID_SEQ",           BUGBOARD_DB_TABLE_PREFIX."bug_id");
define("BUGBOARD_BUG_TEXT_ID_SEQ",      BUGBOARD_DB_TABLE_PREFIX."bug_text_id");
define("BUGBOARD_BUG_FILE_ID_SEQ",      BUGBOARD_DB_TABLE_PREFIX."bug_file_id");
define("BUGBOARD_BUG_NOTE_ID_SEQ",      BUGBOARD_DB_TABLE_PREFIX."bug_note_id");
define("BUGBOARD_BUG_NOTE_TEXT_ID_SEQ", BUGBOARD_DB_TABLE_PREFIX."bug_note_text_id");
define("BUGBOARD_CATEGORY_ID_SEQ",      BUGBOARD_DB_TABLE_PREFIX."category_id");
define("BUGBOARD_CUSTOM_FIELD_ID_SEQ",  BUGBOARD_DB_TABLE_PREFIX."custom_field_id");
?>