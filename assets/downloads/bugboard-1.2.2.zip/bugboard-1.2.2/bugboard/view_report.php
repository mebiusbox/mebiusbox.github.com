<?php
/**
 * @file
 * @brief ��ݡ���ɽ��
 * @author typezero
 */
?>
<?php
require_once("common.php");
require_once("./templates/view_report.php");


// �����������������å�
if (empty($_GET['bid'])) {
    goto_error_page(lang_get('error', 'illegal_access'));
}
// ��ݡ���¸�ߥ����å�
if (is_report_exists($db_, $_GET['bid']) == false) {
    goto_error_page(lang_get('error', 'report_not_found'));
}


//------------------------------------------------------------


$bid = $_GET['bid'];
$db = &$db_;

print(Bugboard_HeaderTemplate(
    Bugboard_view_report_form_check_js()));

//------------------------------------------------------------

$n_comment = $db_->getOne("SELECT COUNT(*) FROM ".BUGBOARD_BUG_NOTE_TABLE." WHERE bid=?", array($bid));
$enables = array();
if ($n_comment>0) {
    array_push($enables, "comment");
}
if (isset($_SESSION['admin'])) {
    array_push($enables, "edit");
}
if (BUGBOARD_ENABLE_VOTE) {
    array_push($enables, "vote");
}
if (count($enables)>0) {
    print(Bugboard_ViewTemplateCmdbar("", $enables));
}

//------------------------------------------------------------

$bug_fields   = $db->getRow("SELECT * FROM ".BUGBOARD_BUG_TABLE." WHERE id=?", array($bid), DB_FETCHMODE_ASSOC);
$bug_body     = $db->getRow("SELECT * FROM ".BUGBOARD_BUG_TEXT_TABLE." WHERE id=?", array($bid), DB_FETCHMODE_ASSOC);

$al = 0;

// custom field
$custom_fields = array();
$enable_fields = $db->getCol("SELECT id FROM ".BUGBOARD_CUSTOM_FIELD_TABLE, 0);
foreach($enable_fields as $fid) {
    $custom_field_name = $db->getOne("SELECT name FROM ".BUGBOARD_CUSTOM_FIELD_TABLE." WHERE id=?", array($fid));
    $custom_field_value = $db->getOne("SELECT value FROM ".BUGBOARD_CUSTOM_FIELD_STRING_TABLE." WHERE fid=? AND bid=?", array($fid,$bid));
    $custom_fields[$custom_field_name] = $custom_field_value;
}


// body

$tbl = new Gull_Table_Html(array("class"=>"listbox", "style"=>"font-size:10pt"));

$param = array("style"=>"width:20%");
$tbl->beginRow();
$tbl->insertHeadCenter("ID",             $param);
$tbl->insertHeadCenter("���ƥ���",       $param);
$tbl->insertHeadCenter("������",         $param);
$tbl->insertHeadCenter("���ơ�����",     $param);
$tbl->insertHeadBlank();
$tbl->endRow();

$tbl->beginRow();
$tbl->insertDataCenter(id_to_str($bug_fields['id']));
$tbl->insertDataCenter(htmlspecialchars($bug_fields['category']));
$tbl->insertDataCenter(lang_get('bug_severity', $bug_fields['severity']));
$tbl->insertDataCenter(lang_get('bug_status', $bug_fields['status']), array("class"=>getBugStatusClass($bug_fields['status'])));
$tbl->insertDataBlank();
$tbl->endRow();
$tbl->nextGrid();

$tbl->beginRow();
$tbl->insertHeadCenter("����");
$tbl->insertHeadCenter("�����");
$tbl->insertHeadCenter("�ǽ�������");
$tbl->insertHeadCenter("�ǽ�������");
if (BUGBOARD_ENABLE_VOTE) {
    $tbl->insertHeadCenter("��ɼ��");
} else {
    $tbl->insertHeadBlank();
}
$tbl->endRow();

$tbl->beginRow();
$tbl->insertDataCenter(htmlspecialchars($bug_fields['reporter']));
$tbl->insertDataCenter(date_as_text($bug_fields['date_submitted']), array("nowrap"));
$tbl->insertDataCenter(htmlspecialchars($bug_fields['last_updater']));
$tbl->insertDataCenter(date_as_text($bug_fields['last_updated']));
if (BUGBOARD_ENABLE_VOTE) {
    $tbl->insertDataCenter($bug_fields['vote_count']);
} else {
    $tbl->insertDataBlank();
}
$tbl->endRow();
$tbl->nextGrid();

$tbl->insertBlankRow();

$tbl->beginRow();
$tbl->insertHead("����");
$tbl->insertData('<div class="report_summary">'.htmlspecialchars($bug_fields['summary']).'</div>', array("colspan"=>"4"));
$tbl->endRow();
$tbl->nextGrid();

$tbl->beginRow();
$tbl->insertHead("�ܺ�");
$tbl->insertData('<div class="report_body">'.nl2br(htmlspecialchars($bug_body['body'])).'</div>', array("colspan"=>"4"));
$tbl->endRow();
$tbl->nextGrid();

// custom fields

if (count($custom_fields)>0) {
    $tbl->insertBlankRow();
    foreach ($custom_fields as $name=>$value) {
        $tbl->beginRow();
        $tbl->insertHead(htmlspecialchars($name));
        $tbl->insertData(nl2br(htmlspecialchars($value)), array("colspan"=>4));
        $tbl->endRow();
        $tbl->nextGrid();
    }
}

// attachment files
$cnt = $db->getOne("SELECT COUNT(*) FROM ".BUGBOARD_BUG_FILE_TABLE." WHERE bid=?", array($bid));
if ($cnt > 0) {
    
    $rs = $db->query("SELECT * FROM ".BUGBOARD_BUG_FILE_TABLE." WHERE bid=?", array($bid));

   $tbl->insertBlankRow();
    
    while ($f = $rs->fetchRow(DB_FETCHMODE_ASSOC)) {
        $tbl->beginRow();
        $tbl->insertHead("ź�եե�����");

        $fname_html = htmlspecialchars($f['filename']);

        $html  = '<a href="file_download.php?fid='.$f['id'].'">'.$fname_html.'</a>';
        $html .= '&nbsp;('.$f['filesize'].' bytes)&nbsp;'.date_as_text($f['date_added']);
        $html .= '&nbsp;';
        $html .= "<br>";
        $tbl->insertData($html, array("colspan"=>2));

        if (mb_eregi("\.jpg|\.png|\.bmp|\.gif$", $fname_html)) {
            $html = '<a href="file_view.php?fid='.$f['id'].'" target="_blank">[�֥饦����ɽ��]</a>';
            $tbl->insertDataCenter($html);
        }
        else {
            $tbl->insertDataBlank();
        }

        if (isset($_SESSION['admin'])) {
            $html = make_tag_closed("a",
                                    array("href"=>"bug_report_action.php?bid=".$bid."&amp;acttype=remove_file&amp;fid=".$f['id']),
                                    '[���]');
            $tbl->insertDataCenter($html);
        }
        else {
            $tbl->insertDataBlank();
        }

        $tbl->endRow();
        $tbl->nextGrid();
    }
}


// update

if (isset($_SESSION['admin'])) {

    $tbl->insertBlankRow();
    $tbl->beginRow();
    $tbl->insertHeadBlank();
    $str = make_tag("form", array("action"=>"bug_report_edit.php?bid=".$bid,
                                  "method"=>"post"));
    $str.= make_tag("input", array("type"=>"submit", "value"=>"���Խ���"));
    $str.= "</form>";
    $tbl->insertData($str, array("colspan"=>4));
    $tbl->endRow();
    $tbl->nextGrid();
    
}

$tbl->endTable();

print(Bugboard_ViewTemplateBody($tbl->to_html()));



// ---------- comment ----------


// comment
$sql_gen = new Sql_Gen_Select(BUGBOARD_BUG_NOTE_TABLE.", ".BUGBOARD_BUG_NOTE_TEXT_TABLE);
$sql_gen->set_field(array(BUGBOARD_BUG_NOTE_TABLE.".*", BUGBOARD_BUG_NOTE_TEXT_TABLE.".body"));
$sql_gen->set_where(BUGBOARD_BUG_NOTE_TABLE.".bid=? AND ".BUGBOARD_BUG_NOTE_TABLE.".body_id = ".BUGBOARD_BUG_NOTE_TEXT_TABLE.".id");
$sql_gen->set_order("date_submitted ASC");

$rs = $db->query($sql_gen->gen(), array($bid));
if (DB::isError($rs)) {
    goto_error_page("�����Ȥμ����˼���", __FILE__.",".__LINE__);
}
if ($rs->numRows()>0) {
    $tbl = new Gull_Table_Html(array("class"=>"listbox"));
    $tbl->setInterlaceMode(true);

    while ($comment = $rs->fetchRow(DB_FETCHMODE_ASSOC)) {

        $name = htmlspecialchars(bugboard_mb_strip_nl($comment['name']));
        $tbl->beginRow();
        $str = make_tag_closed("a", array("name"=>"comment-".$comment['id']));
        $str.= $name."<br>";
        $str.= '<span class="small_normal">';
        $str.= date_as_text($comment['date_submitted'])."<br>";

        if (isset($_SESSION['admin'])) {
            $str.= make_tag_closed("a", array("href"=>"bug_report_action.php?bid=".$bid."&amp;acttype=remove_comment&amp;cid=".$comment['id']),
                                   "[���]");
        }
        
        $str.= '</span>';
        $tbl->insertHead($str, array("width"=>"25%"));
        $tbl->insertData("<div class=\"report_body\">".nl2br(htmlspecialchars($comment['body']))."</div>");
        $tbl->endRow();
    }

    $tbl->endTable();

    print(Bugboard_ViewTemplateComment($tbl->to_html()));
}

// operations
if (isset($_SESSION['admin'])) {
    print(Bugboard_ViewTemplateEdit($bid));
}


// add file

if (BUGBOARD_ENABLE_ATTACH_FILE) {
    $tbl = new Gull_Table_Html(array("class"=>"listbox"));
    $tbl->setInterlaceMode(true);

    $tbl->beginRow();
    $tbl->insertHead('�ե�����̾<br><span class="small_normal">(max file size : '.BUGBOARD_UPLOAD_FILE_SIZE_MAX_STRING.')</span>', array("width"=>"25%"));
    $tbl->insertData(make_tag("input", array("type"=>"file",
                                             "name"=>"attach_file",
                                             "size"=>"60")));
    $tbl->endRow();

    $tbl->beginRow();
    $tbl->insertHeadBlank();
    $tbl->insertData(make_tag("input", array("type"=>"submit", "value"=>"���ɲá�")));
    $tbl->endTable();

    print(Bugboard_ViewTemplateAttachFile($bid, $tbl->to_html()));
}



// add comment

$comment_name = isset($_SESSION['tmp']['name']) ? $_SESSION['tmp']['name'] : "";
$comment_body = isset($_SESSION['tmp']['body']) ? $_SESSION['tmp']['body'] : "";

$tbl = new Gull_Table_Html(array("class"=>"listbox"));
$tbl->setInterlaceMode(true);

$tbl->beginRow();
$tbl->insertHead("̾��", array("width"=>"25%"));
$tbl->insertData(make_input_tag("text", "name", $comment_name, array("size"=>40)));
$tbl->endRow();

$tbl->beginRow();
$tbl->insertHead("����������", array("width"=>"25%"));
$tbl->insertData(make_tag_closed("textarea", array("name"=>"comment","cols"=>80, "rows"=>8), $comment_body));
$tbl->endRow();

if (bugboard_captcha_is_enable()) {

    $img_src = bugboard_captcha_url();
    if (!empty($img_src)) {
    
        $tbl->beginRow();
        $tbl->insertHead("", array("width"=>"25%"));
        $tbl->insertData("<img src=\"$img_src?".time()."\" border=\"0\">");
        $tbl->endRow();

        $tbl->beginRow();
        $tbl->insertHead("��ƥ���", array("width"=>"25%"));
        $tbl->insertData(make_input_tag("text", "regkey", "", array("size"=>40)));
        $tbl->endRow();

    } elseif (BUGBOARD_CAPTCHA_PASSWORD) {

        $tbl->beginRow();
        $tbl->insertHead("��ƥ���", array("width"=>"25%"));
        $tbl->insertData(make_input_tag("password", "regkey", "", array("size"=>40)));
        $tbl->endRow();

    }
    
} else {
    unset($_SESSION['code']);
}

$tbl->beginRow();
$tbl->insertHeadBlank();
$tbl->insertData(make_tag("input", array("type"=>"submit", "value"=>"���ɲá�")));
$tbl->endTable();

print(Bugboard_ViewTemplateAddComment($bid, $tbl->to_html()));


// vote
if (BUGBOARD_ENABLE_VOTE) {
    print(Bugboard_ViewTemplateVote($bid));
}

//
if (isset($_SESSION['admin'])) {
    print(Bugboard_ViewTemplateDelete($bid));
}

print(Bugboard_FooterTemplate());

?>

