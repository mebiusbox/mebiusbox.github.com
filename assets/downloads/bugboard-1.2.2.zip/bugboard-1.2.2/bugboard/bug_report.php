<?php
/**
 * @file
 * @brief ��ݡ��Ⱥ���
 * @author typezero
 */
?>
<?php
require_once("common.php");

//------------------------------------------------------------


$form_values = array();
if (empty($_SESSION['form_values'])) {
    $form_values['name']     = "";
    $form_values['category'] = null;
    $form_values['severity'] = BUGBOARD_BUG_SEVERITY_MINOR;
    $form_values['summary']  = "";
    $form_valeus['body']     = "";
}
else {
    $form_values = $_SESSION['form_values'];
    unset($_SESSION['form_values']);
}


//------------------------------------------------------------


$db  = $db_;

$html  = '<div class="sub_contents"><div class="sub_title">������ݡ���</div>';
$html .= make_tag("form",
                  array("action"=>"bug_report_check.php",
                        "method"=>"post",
                        "enctype"=>"multipart/form-data",
                        "name"=>"report_form",
                        "onSubmit"=>"return report_form_check()"));
$tbl = new Gull_Table_Html(array("class"=>"listbox"));
$tbl->setInterlaceMode(true);

$tbl->beginRow();
$tbl->insertHead("���ƥ���");
$categories = $db->getCol("SELECT category FROM ".BUGBOARD_CATEGORY_TABLE, 0);
$tmp = null;
foreach($categories as $value) {
    $tmp[$value] = $value;
}
$tbl->insertData(make_select_tag($tmp, $form_values['category'], array("name"=>"category")));
$tbl->endRow();

$tbl->beginRow();
$tbl->insertHead("������");
$tbl->insertData(make_select_tag(lang_get('bug_severity'),
                                 $form_values['severity'], array("name"=>"severity")));
$tbl->endRow();

//$tbl->insertBlankRow();

$tbl->beginRow();
$tbl->insertHead(FORM_REQUIRED_MARK.lang_get('name'));
$tbl->insertData(make_tag("input", array("type"=>"text",
                                         "name"=>"name",
                                         "size"=>30,
                                         "maxlength"=>32,
                                         "value"=>$form_values['name'])));
$tbl->endRow();

//$tbl->insertBlankRow();

$tbl->beginRow();
$tbl->insertHead(FORM_REQUIRED_MARK.lang_get('bug_summary_name'));
$tbl->insertData(make_tag("input", array("type"=>"text",
                                         "name"=>"summary",
                                         "size"=>100,
                                         "maxlength"=>128,
                                         "value"=>$form_values['summary'])));
$tbl->endRow();

$tbl->beginRow();
$tbl->insertHead(FORM_REQUIRED_MARK.lang_get('bug_body_name'));
$tbl->insertData(make_tag_closed("textarea",
                                 array("name"=>"body",
                                       "cols"=>80,
                                       "rows"=>8),
                                 $form_values['body']));
                                                   
$tbl->endRow();

// custom field
$fields = $db->query("SELECT * FROM ".BUGBOARD_CUSTOM_FIELD_TABLE." ORDER BY seq");
while ($field_param = $fields->fetchRow(DB_FETCHMODE_ASSOC)) {
    
    $cf_name = "__custom_field_".$field_param['id'];
    $default = (empty($form_values[$cf_name])) ? $field_param['default_value'] : $form_values[$cf_name];

    $tbl->beginRow();
    $tbl->insertHead($field_param['name']);

    switch ($field_param['type']) {
    case BUGBOARD_CUSTOM_FIELD_TYPE_STRING:
    case BUGBOARD_CUSTOM_FILED_TYPE_NUMBER:
        $tbl->insertData(make_tag("input", array("type"=>"text",
                                                 "size"=>100,
                                                 "name"=>$cf_name,
                                                 "value"=>$default)));
        break;

    case BUGBOARD_CUSTOM_FIELD_TYPE_LIST:
        $values = explode("|", $field_param['possible_values']);
        $tmp = null;
        foreach($values as $value) {
            $tmp[$value] = $value;
        }
        $tbl->insertData(make_select_tag($tmp, $default, array("name"=>$cf_name)));
        break;

    case BUGBOARD_CUSTOM_FIELD_TYPE_CHECKBOX:
        
        $possible_values = explode("|", $field_param['possible_values']);
        $default_values  = explode("|", $field_param['default_value']);

        $space  = "&nbsp;";
        $space2 = $space.$space;
        $buf = new Html_Buffer;
        $tmp = new Html_Writer($buf);
        $cnt = 0;
        foreach ($possible_values as $value) {
            if ($value == "") {
                $tmp->writebr();
            }
            else {
                $opt = array("type"=>"checkbox", "name"=>$cf_name."_".$cnt, "value"=>$value);
                if (in_array($value, $default_values)) {
                    array_push($opt, "checked");
                }
                $tmp->write(make_tag("input", $opt));
                $tmp->writeln($space.$value.$space2);
                $cnt++;
            }
        }
        $tbl->insertData($buf->get());
        break;

    case BUGBOARD_CUSTOM_FIELD_TYPE_RADIO:

        $space  = "&nbsp;";
        $space2 = $space.$space;
        
        $values = explode("|", $field_param['possible_values']);
        $tmp = "";

        $buf = new Html_Buffer;
        $tmp = new Html_Writer($buf);
        
        foreach($values as $value) {
            if ($value == "") {
                $tmp->writebr();
            }
            else {
                $opt = array("type"=>"radio",
                             "name"=>$cf_name,
                             "value"=>$value);
                if ($default == $value) {
                    array_push($opt, "checked");
                }

                $tmp->write(make_tag("input", $opt));
                $tmp->writeln($space.$value.$space2);
            }
        }
        $tbl->insertData($buf->get());
        break;

    case BUGBOARD_CUSTOM_FIELD_TYPE_TEXT:
        $tbl->insertData(make_tag_closed("textarea", array("name"=>$cf_name,
                                                           "cols"=>80,
                                                           "rows"=>8),
                                         $default));
        break;
    }

    $tbl->endRow();
}


if (BUGBOARD_ENABLE_ATTACH_FILE) {
    $tbl->beginRow();
    $tbl->insertHead('ź�եե�����<br><span class="small_normal">(max file size : '.BUGBOARD_UPLOAD_FILE_SIZE_MAX_STRING.')</span>');

    $file_form  = make_input_tag("hidden", "MAX_FILE_SIZE", BUGBOARD_UPLOAD_FILE_SIZE_MAX);
    $file_form .= make_tag("input", array("type"=>"file",
                                          "name"=>"attach_file",
                                          "size"=>"60"));
    $tbl->insertData($file_form);
    $tbl->endRow();
}


//

$tbl->beginRow();
$tbl->insertHead("&nbsp;");
$tmp  = make_tag("input", array("type"=>"submit", "value"=>"����Ͽ��"));
$tmp .= '&nbsp;<span style="color:red">*</span>ɬ�ܹ���';
$tbl->insertData($tmp);
$tbl->endRow();

$tbl->endTable();

$content = $html.$tbl->to_html()."</form></div>";

print(Bugboard_HeaderTemplate(
    Bugboard_report_form_check_js()));
print($content);
print(Bugboard_FooterTemplate());

?>
