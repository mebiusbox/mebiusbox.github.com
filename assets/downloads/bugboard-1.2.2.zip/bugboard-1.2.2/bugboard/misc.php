<?php
/**
 * @file
 * @brief �󤻽���
 * @author typezero
 */

require_once("DB.php");

/**
 */
function getBugStatusClass($status) {

    switch ($status) {
    case BUGBOARD_BUG_STATUS_NEW:       return "grid_new";
    case BUGBOARD_BUG_STATUS_CHECKED:   return "grid_checked";
    case BUGBOARD_BUG_STATUS_FEEDBACK:  return "grid_feedback";
    case BUGBOARD_BUG_STATUS_START:     return "grid_start";
    case BUGBOARD_BUG_STATUS_NOTREPRO:  return "grid_notrepro";
    case BUGBOARD_BUG_STATUS_FIXED:     return "grid_fixed";
    case BUGBOARD_BUG_STATUS_SUSPEND:   return "grid_suspend";
    case BUGBOARD_BUG_STATUS_REJECTED:  return "grid_rejected";
    case BUGBOARD_BUG_STATUS_CLOSED:    return "grid_closed";
    }

    return "";
}

/**
 */
function bugboard_upload_file($upload_dir, $fileinfo)
{
    do {
        $tmp = $upload_dir.md5(uniqid(mt_rand(),TRUE));
    } while (file_exists($tmp));

    if (move_uploaded_file($fileinfo['tmp_name'], $tmp)) {
        return $tmp;
    }
    else {
        return null;
    }
}

/**
 * @brief ��ݡ��Ȥ�¸�ߤ�Ĵ�٤�
 */
function is_report_exists(&$db, $bid) {

    $id = $db->getOne("SELECT id FROM ".BUGBOARD_BUG_TABLE." WHERE id=?", array($bid));
    if (empty($id)) {
        return false;
    }

    return true;
}

/**
 * @brief ����������ܤ�¸�ߤ�Ĵ�٤�
 */
function is_custom_field_exists(&$db, $fid) {

    $id = $db->getOne("SELECT id FROM ".BUGBOARD_CUSTOM_FIELD_TABLE." WHERE id=?", array($fid));
    if (empty($id)) {
        return false;
    }

    return true;
}

/**
 * @brief ź�եե������¸�ߤ�Ĵ�٤�
 */
function is_attach_file_exists(&$db, $fid) {

    $id = $db->getOne("SELECT id FROM ".BUGBOARD_BUG_FILE_TABLE." WHERE id=?", array($fid));
    if (empty($id)) {
        return false;
    }

    return true;
}

/**
 * @brief �����Ȥ�¸�ߤ�Ĵ�٤�
 */
function is_comment_exists(&$db, $cid) {

    $id = $db->getOne("SELECT id FROM ".BUGBOARD_BUG_NOTE_TABLE." WHERE id=?", array($cid));
    if (empty($id)) {
        return false;
    }

    return true;
}

/**
 * @brief �桼������������Ȥ�¸�ߤ�Ĵ�٤�
 */
function is_user_exists(&$db, $uid) {

    $id = $db->getOne("SELECT id FROM ".BUGBOARD_USER_TABLE." WHERE id=?", array($uid));
    if (empty($id)) {
        return false;
    }

    return true;
}


//------------------------------------------------------------
//          for admin
//------------------------------------------------------------
function make_admin_commands() {

    $html = "";
    
    if (isset($_SESSION['admin'])) {
        $html .= make_tag_closed("a",
                                 array("href"=>"index.php",
                                       "class"=>"menulist"),
                                 "�ᥤ�����");
        $html .= "&nbsp;|&nbsp;";
        $html .= make_tag_closed("a",
                                 array("href"=>"manage_user.php",
                                       "class"=>"menulist"),
                                 "�桼��������");
        $html .= "&nbsp;|&nbsp;";
        $html .= make_tag_closed("a",
                                 array("href"=>"manage_category.php",
                                       "class"=>"menulist"),
                                 "���ƥ������");
        $html .= "&nbsp;|&nbsp;";
        $html .= make_tag_closed("a",
                                 array("href"=>"manage_custom_field.php",
                                       "class"=>"menulist"),
                                 "����������ܴ���");
        $html .= "&nbsp;|&nbsp;";
        $html .= make_tag_closed("a",
                                 array("href"=>"logout.php",
                                       "class"=>"menulist"),
                                 "����������");
    } else {
        $html = make_tag_closed("a",
                                array("href"=>"login.php",
                                      "class"=>"menulist"),
                                "��������");
    }

    if (BUGBOARD_GENERATE_RSS) {
        $html .= "&nbsp;|&nbsp;";
        $html .= make_tag_closed("a",
                                 array("href"=>"./rss/?feed=rss",
                                       "class"=>"menulist"),
                                 "RSS");
    }
    
    if (BUGBOARD_GENERATE_COMMENTS_RSS) {
        $html .= "&nbsp;|&nbsp;";
        $html .= make_tag_closed("a",
                                 array("href"=>"./rss/?feed=comments-rss",
                                       "class"=>"menulist"),
                                 "������RSS");
    }

    return $html;
}





//------------------------------------------------------------
//          string utility
//------------------------------------------------------------

/**
 * @brief ����ζ�����������Ѷ����б���
 */
function bugboard_mb_trim($str) {
    return mb_ereg_replace('^([ ��]*)([^ ��]*)([ ��]*)$', '\2', $str);
}

/**
 * @brief ���Ժ��
 */
function bugboard_mb_strip_nl($str) {
    return mb_ereg_replace('[\n\r]', '', $str);
}

/**
 */
function cnv_enc($str) {
    return mb_convert_encoding($str, BUGBOARD_INTERNAL_ENCODING, BUGBOARD_HTML_ENCODING);
}

/**
 */
function encoding_to_db($str) {
    return mb_convert_encoding($str, BUGBOARD_DB_ENCODING, BUGBOARD_INTERNAL_ENCODING);
}

/**
 */
function encoding_to_internal($str) {
    return mb_convert_encoding($str, BUGBOARD_INTERNAL_ENCODING, BUGBOARD_DB_ENCODING);
}

/**
 */
function id_to_str($id) {
    return sprintf("%07d",$id);
}

//---------------------------------------------------------------------------
/**
 * @brief ���դ�ʸ������Ѵ���YYYY-MM-DD HH:MM �η������֤�
 *
 * MySQL 4.0.* ������ TIMESTAMP �� YYYYMMDDHHMMSS��
 * MySQL 4.1.* �ʹߤ� TIMESTAMP �� YYYY-MM-DD HH:MM:SS��
 * PostgresSQL �� TIMESTAMP �� YYYY-MM-DD HH:MM:SS��
 */
//---------------------------------------------------------------------------
function date_as_text($date) {
    if (strcmp(BUGBOARD_DB_SQLTYPE,"mysql") == 0) {
        $wk  = substr($date, 0,4)."-";
        $wk .= substr($date, 4,2)."-";
        $wk .= substr($date, 6,2)." ";
        $wk .= substr($date, 8,2).":";
        $wk .= substr($date,10,2);
        return $wk;
    } else {
        return substr($date, 0, 16);
    }
}

//------------------------------------------------------------
//          report utility
//------------------------------------------------------------

/**
 * @brief ��ݡ��Ȥ���Ӥ���˴ط�����쥳���ɤ�ǡ����١�������������
 */
function remove_report(&$db, $bid) {

    // MySQL 4.* �ϥ��֥����꡼�򥵥ݡ��Ȥ��Ƥ��ʤ��ΤǻȤ�ʤ��褦�ˤ���

    // ����
    $rs = $db->getCol("SELECT body_id FROM ".BUGBOARD_BUG_TABLE." WHERE id=?", 0, array($bid));
    if (count($rs)>0) {
        $idlist = "(".implode(",", $rs).")";
        $db->query("DELETE FROM ".BUGBOARD_BUG_TEXT_TABLE." WHERE id IN ".$idlist);
    }
    
    // ź�եե�����
    $rs = $db->query("SELECT * FROM ".BUGBOARD_BUG_FILE_TABLE." WHERE bid=?", array($bid));
    while ($row = $rs->fetchRow(DB_FETCHMODE_ASSOC)) {
        unlink($row['diskfile']);
    }

    $db->query("DELETE FROM ".BUGBOARD_BUG_FILE_TABLE." WHERE bid=?", array($bid));
    
    // ������
    $rs = $db->getCol("SELECT body_id FROM ".BUGBOARD_BUG_NOTE_TABLE." WHERE bid=?", 0, array($bid));
    if (count($rs)>0) {
        $idlist = "(".implode(",", $rs).")";
        $db->query("DELETE FROM ".BUGBOARD_BUG_NOTE_TEXT_TABLE." WHERE id IN ".$idlist);
    }
    
    $db->query("DELETE FROM ".BUGBOARD_BUG_NOTE_TABLE." WHERE bid=?", array($bid));
    
    // �����������
    $db->query("DELETE FROM ".BUGBOARD_CUSTOM_FIELD_STRING_TABLE." WHERE bid=?", array($bid));
    
    // ����
    $db->query("DELETE FROM ".BUGBOARD_BUG_TABLE." WHERE id=?", array($bid));
}

//------------------------------------------------------------
//          mail utility
//------------------------------------------------------------
function bugboard_send_mail($param)
{
    mb_language('Japanese');
    mb_internal_encoding(BUGBOARD_INTERNAL_ENCODING);
    
    $to = mb_convert_kana(implode(",", $param['email_list']));
    $subject = mb_convert_kana($param['subject']);
    $body    = mb_convert_kana($param['body']);
    
    $header  = "From: ".mb_encode_mimeheader(mb_convert_kana(htmlspecialchars(PROJECT_NAME)))."-Bugboard<".$param['from'].">\n";
    
    if (isset($param['cc_list']) && count($param['cc_list']) > 0) {
        $header .= "Cc: ".implode(',', $param['cc_list'])."\n";
    }
    
    if (isset($param['bcc_list']) && count($param['bcc_list']) > 0) {
        $header .= "Bcc: ".implode(',', $param['bcc_list'])."\n";
    }
    
    mb_send_mail($to, $subject, $body, $header);
}
?>